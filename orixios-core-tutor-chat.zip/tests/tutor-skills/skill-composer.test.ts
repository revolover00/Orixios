import { describe, expect, it } from 'vitest';
import {
  composeTutorInstructions,
  DEFAULT_SKILL_ORDER,
  getDefaultTutorSkills,
} from '@/lib/tutor-skills/skill-composer';
import type { TutorPromptContext, TutorSkill } from '@/lib/tutor-skills/types';

function makeContext(): TutorPromptContext {
  return {
    subjectId: 'mathematics',
    subjectName: 'الرياضيات',
    sessionId: 'session-12345678',
    groundedContext: 'سياق تجريبي',
    hasAvailableSource: true,
  };
}

function countOccurrences(haystack: string, needle: string): number {
  let count = 0;
  let index = haystack.indexOf(needle);
  while (index !== -1) {
    count += 1;
    index = haystack.indexOf(needle, index + needle.length);
  }
  return count;
}

describe('getDefaultTutorSkills', () => {
  it('يرجِع المهارات الأساسية الثلاث بترتيب ثابت', () => {
    const skills = getDefaultTutorSkills();

    expect(skills.map((skill) => skill.name)).toEqual([...DEFAULT_SKILL_ORDER]);
    expect(DEFAULT_SKILL_ORDER).toEqual([
      'session-subject-lock',
      'grounded-source',
      'explanation',
    ]);
  });
});

describe('composeTutorInstructions', () => {
  it('يدمج المهارات الافتراضية بترتيب ثابت وقابل للاختبار', () => {
    const composed = composeTutorInstructions(makeContext());

    const idxLock = composed.indexOf('## قواعد المادة والجلسة');
    const idxGrounded = composed.indexOf('## قواعد المصدر الموثوق');
    const idxStyle = composed.indexOf('## أسلوب الشرح');

    expect(idxLock).toBeGreaterThan(-1);
    expect(idxGrounded).toBeGreaterThan(idxLock);
    expect(idxStyle).toBeGreaterThan(idxGrounded);
  });

  it('حتمي: نفس السياق يعطي نفس الناتج دائمًا', () => {
    const context = makeContext();

    expect(composeTutorInstructions(context)).toBe(composeTutorInstructions(context));
  });

  it('لا يكرر نفس المهارة (أول ظهور يفوز)', () => {
    const skills = [...getDefaultTutorSkills(), ...getDefaultTutorSkills()];
    const composed = composeTutorInstructions(makeContext(), skills);

    expect(countOccurrences(composed, '## قواعد المادة والجلسة')).toBe(1);
    expect(countOccurrences(composed, '## قواعد المصدر الموثوق')).toBe(1);
    expect(countOccurrences(composed, '## أسلوب الشرح')).toBe(1);
  });

  it('يتجاهل المهارات ذات التعليمات الفارغة', () => {
    const emptySkill: TutorSkill = { name: 'empty-skill', getInstructions: () => '   ' };

    const composed = composeTutorInstructions(makeContext(), [...getDefaultTutorSkills(), emptySkill]);

    expect(composed.trim().length).toBeGreaterThan(0);
    expect(composed).not.toContain('empty-skill');
  });

  it('يسمح بإضافة مهارة جديدة دون تعديل بقية النظام', () => {
    const customSkill: TutorSkill = {
      name: 'custom-focus',
      getInstructions: () => '## تركيز إضافي\n- CUSTOM_SKILL_MARKER',
    };

    const composed = composeTutorInstructions(makeContext(), [
      ...getDefaultTutorSkills(),
      customSkill,
    ]);

    expect(composed).toContain('CUSTOM_SKILL_MARKER');
    // المهارات الأساسية ما زالت حاضرة.
    expect(composed).toContain('## قواعد المادة والجلسة');
    expect(composed).toContain('## قواعد المصدر الموثوق');
    expect(composed).toContain('## أسلوب الشرح');
  });

  it('مهارة مخصصة بنفس اسم مهارة أساسية تحل محله حسب ترتيب المصفوفة', () => {
    const customExplanation: TutorSkill = {
      name: 'explanation',
      getInstructions: () => '## أسلوب الشرح المخصص',
    };

    const composed = composeTutorInstructions(makeContext(), [
      ...getDefaultTutorSkills().slice(0, 2),
      customExplanation,
    ]);

    expect(composed).toContain('## أسلوب الشرح المخصص');
    // التعليمات الافتراضية لأسلوب الشرح غير مكررة مع النسخة المخصصة.
    expect(composed).not.toContain('اتبع الأسلوب السقراطي');
  });

  it('يمرر نفس السياق لكل المهارات ولا يسمح بمادة مختلفة', () => {
    const context = makeContext();
    const seenSubjects: string[] = [];
    const observerSkill: TutorSkill = {
      name: 'observer',
      getInstructions: (ctx) => {
        seenSubjects.push(ctx.subjectName);
        return '';
      },
    };

    composeTutorInstructions(context, [observerSkill, ...getDefaultTutorSkills()]);

    expect(seenSubjects).toEqual(['الرياضيات']);
  });
});
