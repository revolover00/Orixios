/**
 * اختبار ملف .env.example: يضمن وجود الإعدادات المطلوبة دون أي أسرار.
 */

import fs from 'node:fs';
import path from 'node:path';
import { describe, expect, it } from 'vitest';

const ENV_EXAMPLE_PATH = path.resolve(process.cwd(), '.env.example');
const content = fs.readFileSync(ENV_EXAMPLE_PATH, 'utf8');

describe('.env.example', () => {
  it('يحتوي وضع الاختبار التطويري معطلًا افتراضيًا', () => {
    expect(content).toMatch(/DEV_TESTING_MODE=false/);
  });

  it('يعرّف مفتاح التطوير فارغًا دون أي قيمة حقيقية', () => {
    expect(content).toMatch(/^\s*GEMINI_API_KEY=\s*$/m);
  });

  it('يوثق أن مفتاح التطوير لا يُستخدم تلقائيًا', () => {
    expect(content).toContain('DEV_TESTING_MODE=false');
    expect(content.toLowerCase()).toContain('gemini_api_key');
    expect(content).toContain('allowDevEnvironmentFallback');
  });

  it('لا يحتوي على قيم تبدو كمفاتيح حقيقية', () => {
    expect(content).not.toMatch(/AIza[0-9A-Za-z_-]{12,}/);
    expect(content).not.toMatch(/\bsk-[A-Za-z0-9]{16,}/);
  });
});
