import { describe, expect, it } from 'vitest';
import {
  buildGroundedContext,
  getGroundedContentForSubject,
  getGroundedContentForTopic,
  resolveGroundedContext,
} from '@/lib/grounded-knowledge/knowledge-loader';
import {
  KnowledgeError,
  OUT_OF_SOURCE_MESSAGE,
} from '@/lib/grounded-knowledge/knowledge-errors';
import { MOCK_GROUNDED_CONTENT } from '@/lib/grounded-knowledge/mock-content';

describe('تحميل المحتوى حسب المادة', () => {
  it('يحمّل محتوى الرياضيات فقط عند طلب الرياضيات', () => {
    const contents = getGroundedContentForSubject('mathematics');

    expect(contents.length).toBeGreaterThan(0);
    expect(contents.every((item) => item.subjectId === 'mathematics')).toBe(true);
    expect(contents.some((item) => item.topic.includes('المعادلات الخطية'))).toBe(true);
  });

  it('لا يظهر محتوى الفيزياء داخل سياق الرياضيات', () => {
    const mathContext = buildGroundedContext({ subjectId: 'mathematics' });
    const physicsContents = getGroundedContentForSubject('physics');

    expect(physicsContents.length).toBeGreaterThan(0);
    for (const item of physicsContents) {
      expect(mathContext).not.toContain(item.title);
      expect(mathContext).not.toContain(item.content.slice(0, 40));
    }
    // ولا يظهر موضوع الفيزياء نفسه في سياق الرياضيات.
    expect(mathContext).not.toContain('السرعة والمسافة والزمن');
  });

  it('كل عنصر في الـ Mock يعلن صراحة أنه ليس مصدرًا حقيقيًا', () => {
    expect(
      MOCK_GROUNDED_CONTENT.every(
        (item) => item.sourceType === 'mock' && item.sourceReference === 'development-fixture',
      ),
    ).toBe(true);
  });

  it('يرمي KnowledgeError لمادة غير معروفة', () => {
    expect(() => getGroundedContentForSubject('biology')).toThrowError(KnowledgeError);

    try {
      getGroundedContentForSubject('biology');
    } catch (error) {
      expect((error as KnowledgeError).code).toBe('UNKNOWN_SUBJECT');
    }
  });
});

describe('تصفية الموضوعات', () => {
  it('يرجِع محتوى الموضوع المطلوب فقط', () => {
    const contents = getGroundedContentForTopic({
      subjectId: 'physics',
      topic: 'السرعة',
    });

    expect(contents.length).toBeGreaterThan(0);
    expect(contents.every((item) => item.topic.includes('السرعة'))).toBe(true);
  });

  it('بدون موضوع يرجِع كل محتوى المادة', () => {
    const all = getGroundedContentForSubject('mathematics');
    const viaTopic = getGroundedContentForTopic({ subjectId: 'mathematics' });

    expect(viaTopic).toEqual(all);
  });

  it('يرجِع مصفوفة فارغة لموضوع غير موجود دون خلط مواد', () => {
    const contents = getGroundedContentForTopic({
      subjectId: 'mathematics',
      topic: 'الكهرباء',
    });

    expect(contents).toEqual([]);
  });
});

describe('بناء السياق الموثوق', () => {
  it('يبني سياقًا يحتوي على نوع المصدر ومرجعه', () => {
    const context = buildGroundedContext({ subjectId: 'physics' });

    expect(context).toContain('Grounded source');
    expect(context).toContain('Subject: Physics');
    expect(context).toContain('Source type: Mock development fixture');
    expect(context).toContain('Source reference: development-fixture');
    expect(context).toContain('Content:');
  });

  it('يرجِع محتوى الموضوع المحدد داخل السياق', () => {
    const context = buildGroundedContext({
      subjectId: 'chemistry',
      topic: 'العنصر والمركب',
    });

    expect(context).toContain('Topic: العنصر والمركب');
    // السياق يعرض محتوى المصدر نفسه.
    expect(context).toContain('العنصر: مادة نقية لا يمكن تجزئتها');
  });

  it('يضع علامة عدم توفر المصدر لموضوع غير موجود دون توليد بديل', () => {
    const result = resolveGroundedContext({
      subjectId: 'mathematics',
      topic: 'التفاضل والتكامل',
    });

    expect(result.hasAvailableSource).toBe(false);
    expect(result.contents).toEqual([]);
    expect(result.context).toBe('');
  });

  it('لا يستخدم مادة قريبة أو موضوعًا مشابهًا تلقائيًا عند غياب المصدر', () => {
    const result = resolveGroundedContext({
      subjectId: 'arabic',
      topic: 'المعادلات الخطية', // موضوع رياضيات؛ لا يجب استدعاؤه لمادة أخرى
    });

    expect(result.hasAvailableSource).toBe(false);
    expect(result.context).toBe('');
    expect(result.contents).toEqual([]);
  });

  it('حالة النجاح تحمل المواد الفعلية وعلامة التوفر', () => {
    const result = resolveGroundedContext({ subjectId: 'mathematics' });

    expect(result.hasAvailableSource).toBe(true);
    expect(result.contents.length).toBeGreaterThan(0);
    expect(result.subjectId).toBe('mathematics');
    expect(result.context.length).toBeGreaterThan(0);
  });
});

describe('رسالة خارج المصدر القياسية', () => {
  it('معرّفة مرة واحدة في ملف الأخطاء', () => {
    expect(OUT_OF_SOURCE_MESSAGE).toBe('الجزئية دي مش موجودة في المصدر المتاح حاليًا.');
  });
});
