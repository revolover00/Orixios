import { describe, expect, it } from 'vitest';
import {
  getAllSubjects,
  getSubjectById,
  isValidSubjectId,
} from '@/lib/sessions/subject-catalog';
import { matchSubjectName, resolveSubjectFromText } from '@/lib/sessions/subject-matcher';

describe('كتالوج المواد', () => {
  it('يعيد كل المواد النشطة', () => {
    const subjects = getAllSubjects();

    expect(subjects.length).toBeGreaterThanOrEqual(4);
    expect(subjects.map((subject) => subject.id)).toEqual(
      expect.arrayContaining(['mathematics', 'physics', 'chemistry', 'arabic']),
    );
    expect(subjects.every((subject) => subject.isActive)).toBe(true);
    // لكل مادة اسم قياسي واسم عربي.
    expect(subjects.every((subject) => subject.name.length > 0)).toBe(true);
    expect(subjects.every((subject) => subject.nameAr.length > 0)).toBe(true);
  });

  it('يعثر على مادة صحيحة بالـ subjectId', () => {
    const subject = getSubjectById('mathematics');

    expect(subject).not.toBeNull();
    expect(subject?.nameAr).toBe('الرياضيات');
  });

  it('يرفض subjectId غير معروف ويعيد null', () => {
    expect(getSubjectById('biology')).toBeNull();
    expect(getSubjectById('')).toBeNull();
    expect(isValidSubjectId('biology')).toBe(false);
    expect(isValidSubjectId('mathematics')).toBe(true);
  });
});

describe('matchSubjectName — مطابقة اسم المادة', () => {
  it('يطابق "الرياضيات" و"رياضيات" و"math" كتطابق واضح', () => {
    for (const input of ['الرياضيات', 'رياضيات', 'math', 'Mathematics', 'MATHEMATICS']) {
      const result = matchSubjectName(input);

      expect(result.exact?.id, `input: ${input}`).toBe('mathematics');
      expect(result.suggestions).toEqual([]);
    }
  });

  it('يقص المسافات الزائدة قبل المطابقة', () => {
    const result = matchSubjectName('   الرياضيات   ');

    expect(result.exact?.id).toBe('mathematics');
  });

  it('يطابق أسماء الفيزياء والكيمياء والعربية الشائعة', () => {
    expect(matchSubjectName('فيزياء').exact?.id).toBe('physics');
    expect(matchSubjectName('الفيزياء').exact?.id).toBe('physics');
    expect(matchSubjectName('physics').exact?.id).toBe('physics');
    expect(matchSubjectName('كيمياء').exact?.id).toBe('chemistry');
    expect(matchSubjectName('عربي').exact?.id).toBe('arabic');
    expect(matchSubjectName('اللغة العربية').exact?.id).toBe('arabic');
  });

  it('يرجِع اقتراحات عند التطابق الجزئي دون حسم تلقائي', () => {
    const result = matchSubjectName('فيزي');

    expect(result.exact).toBeNull();
    expect(result.suggestions.map((subject) => subject.id)).toContain('physics');
  });

  it('يرجِع اقتراحات لبداية اسم عربية', () => {
    const result = matchSubjectName('رياض');

    expect(result.exact).toBeNull();
    expect(result.suggestions.map((subject) => subject.id)).toContain('mathematics');
  });

  it('لا يختار مادة عند إدخال غامض جدًا', () => {
    for (const input of ['zzz', 'س', 'كمم', '']) {
      const result = matchSubjectName(input);

      expect(result.exact, `input: ${input}`).toBeNull();
      expect(result.suggestions, `input: ${input}`).toEqual([]);
    }
  });

  it('الواجهة التوافقية القديمة تعيد فقط التطابقات التامة', () => {
    expect(resolveSubjectFromText('الرياضيات').matched).toBe(true);
    expect(resolveSubjectFromText('الرياضيات').subjectId).toBe('mathematics');
    expect(resolveSubjectFromText('فيزي').matched).toBe(false);
  });
});
