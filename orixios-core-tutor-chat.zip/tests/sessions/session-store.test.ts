import { describe, expect, it } from 'vitest';
import { SessionError } from '@/lib/sessions/session-errors';
import { LOCAL_STUDENT_ID, sessionStore } from '@/lib/sessions/session-store';
import {
  createSessionSchema,
  sessionIdSchema,
  studentIdSchema,
  subjectIdSchema,
  urlSubjectIdSchema,
} from '@/lib/validation/session-schemas';

function expectSessionError(fn: () => unknown, code: SessionError['code']): SessionError {
  try {
    fn();
  } catch (error) {
    expect(error).toBeInstanceOf(SessionError);
    const sessionError = error as SessionError;
    expect(sessionError.code).toBe(code);
    return sessionError;
  }
  throw new Error(`Expected SessionError(${code}) but nothing was thrown`);
}

describe('إنشاء الجلسات وقراءتها', () => {
  it('ينشئ جلسة صحيحة ببيانات كاملة', () => {
    const session = sessionStore.createSession({
      studentId: 'student-create',
      subjectId: 'mathematics',
    });

    expect(session.id).toMatch(/[0-9a-f-]{36}/);
    expect(session.studentId).toBe('student-create');
    expect(session.subjectId).toBe('mathematics');
    expect(session.subjectName).toBe('الرياضيات');
    expect(session.status).toBe('active');
    expect(Number.isNaN(Date.parse(session.startedAt))).toBe(false);
    expect(session.endedAt).toBeUndefined();
  });

  it('ينشئ جلسة بمعرّف صريح ويمنع التكرار فوقه', () => {
    const session = sessionStore.createSession({
      id: 'explicit-session-id-123',
      studentId: 'student-explicit',
      subjectId: 'physics',
    });

    expect(session.id).toBe('explicit-session-id-123');
    expect(sessionStore.getSession('explicit-session-id-123')).not.toBeNull();

    expectSessionError(
      () =>
        sessionStore.createSession({
          id: 'explicit-session-id-123',
          studentId: 'student-explicit',
          subjectId: 'physics',
        }),
      'SESSION_ALREADY_EXISTS',
    );
  });

  it('يرفض إنشاء جلسة بمادة غير صالحة', () => {
    // عبر النوع: نجبر قيمة غير صالحة لاختبار الحماية وقت التشغيل.
    expectSessionError(
      () =>
        sessionStore.createSession({
          studentId: 'student-invalid',
          subjectId: 'biology' as unknown as 'mathematics',
        }),
      'INVALID_SUBJECT',
    );
  });

  it('يسترجع جلسة موجودة ويعيد null لغير الموجودة', () => {
    const session = sessionStore.createSession({
      studentId: 'student-get',
      subjectId: 'physics',
    });

    expect(sessionStore.getSession(session.id)?.id).toBe(session.id);
    expect(sessionStore.getSession('no-such-session-id')).toBeNull();
  });
});

describe('قفل المادة (assertSessionSubject)', () => {
  it('ينجح عند تطابق المادة', () => {
    const session = sessionStore.createSession({
      studentId: 'student-assert-ok',
      subjectId: 'chemistry',
    });

    const asserted = sessionStore.assertSessionSubject({
      sessionId: session.id,
      subjectId: 'chemistry',
    });

    expect(asserted.id).toBe(session.id);
  });

  it('يرمي SUBJECT_MISMATCH عند اختلاف المادة', () => {
    const session = sessionStore.createSession({
      studentId: 'student-mismatch',
      subjectId: 'mathematics',
    });

    expectSessionError(
      () =>
        sessionStore.assertSessionSubject({
          sessionId: session.id,
          subjectId: 'physics',
        }),
      'SUBJECT_MISMATCH',
    );
  });

  it('لا يغيّر مادة الجلسة بعد فشل المطابقة', () => {
    const session = sessionStore.createSession({
      studentId: 'student-no-mutate',
      subjectId: 'mathematics',
    });

    try {
      sessionStore.assertSessionSubject({ sessionId: session.id, subjectId: 'arabic' });
    } catch {
      // متوقع
    }

    const after = sessionStore.getSession(session.id);
    expect(after?.subjectId).toBe('mathematics');
    expect(after?.status).toBe('active');
  });

  it('يرمي SESSION_NOT_FOUND لجلسة غير موجودة', () => {
    expectSessionError(
      () =>
        sessionStore.assertSessionSubject({
          sessionId: 'missing-session-id',
          subjectId: 'mathematics',
        }),
      'SESSION_NOT_FOUND',
    );
  });

  it('يرمي INVALID_SUBJECT لمعرّف مادة غير معروف في الطلب', () => {
    const session = sessionStore.createSession({
      studentId: 'student-invalid-assert',
      subjectId: 'mathematics',
    });

    expectSessionError(
      () =>
        sessionStore.assertSessionSubject({
          sessionId: session.id,
          subjectId: 'history',
        }),
      'INVALID_SUBJECT',
    );
  });
});

describe('إنهاء الجلسات', () => {
  it('ينهي الجلسة ويسجل endedAt', () => {
    const session = sessionStore.createSession({
      studentId: 'student-end',
      subjectId: 'arabic',
    });

    const ended = sessionStore.endSession(session.id);

    expect(ended.status).toBe('ended');
    expect(ended.endedAt).toBeTruthy();
    expect(Number.isNaN(Date.parse(ended.endedAt ?? ''))).toBe(false);
  });

  it('يرفض استخدام جلسة منتهية', () => {
    const session = sessionStore.createSession({
      studentId: 'student-ended-use',
      subjectId: 'mathematics',
    });
    sessionStore.endSession(session.id);

    expectSessionError(
      () =>
        sessionStore.assertSessionSubject({
          sessionId: session.id,
          subjectId: 'mathematics',
        }),
      'SESSION_ENDED',
    );
  });

  it('يرفض إنهاء جلسة منتهية أصلًا', () => {
    const session = sessionStore.createSession({
      studentId: 'student-double-end',
      subjectId: 'physics',
    });
    sessionStore.endSession(session.id);

    expectSessionError(() => sessionStore.endSession(session.id), 'SESSION_ENDED');
  });

  it('لا يعيد الجلسات المنتهية من getActiveSessionForSubject', () => {
    const studentId = 'student-active-only';
    const session = sessionStore.createSession({ studentId, subjectId: 'chemistry' });
    expect(sessionStore.getActiveSessionForSubject({ studentId, subjectId: 'chemistry' })?.id).toBe(
      session.id,
    );

    sessionStore.endSession(session.id);

    expect(
      sessionStore.getActiveSessionForSubject({ studentId, subjectId: 'chemistry' }),
    ).toBeNull();
  });
});

describe('عزل جلسات الطلاب', () => {
  it('يعرض جلسات طالب معين فقط', () => {
    const studentA = 'student-iso-a';
    const studentB = 'student-iso-b';
    sessionStore.createSession({ studentId: studentA, subjectId: 'mathematics' });
    sessionStore.createSession({ studentId: studentA, subjectId: 'physics' });
    sessionStore.createSession({ studentId: studentB, subjectId: 'arabic' });

    const sessionsA = sessionStore.listStudentSessions(studentA);
    const sessionsB = sessionStore.listStudentSessions(studentB);

    expect(sessionsA).toHaveLength(2);
    expect(sessionsA.every((session) => session.studentId === studentA)).toBe(true);
    expect(sessionsB).toHaveLength(1);
    expect(sessionsB[0]?.studentId).toBe(studentB);
    expect(sessionStore.listStudentSessions('student-nobody')).toEqual([]);
  });

  it('يجد الجلسة النشطة لمادة طالب محدد فقط', () => {
    const studentId = 'student-active-subject';
    sessionStore.createSession({ studentId, subjectId: 'mathematics' });

    expect(
      sessionStore.getActiveSessionForSubject({ studentId, subjectId: 'mathematics' }),
    ).not.toBeNull();
    expect(
      sessionStore.getActiveSessionForSubject({ studentId: 'other-student', subjectId: 'mathematics' }),
    ).toBeNull();
  });

  it('يوفر معرّف طالب محلي ثابت للمرحلة المؤقتة', () => {
    expect(LOCAL_STUDENT_ID.length).toBeGreaterThan(0);
  });
});

describe('التحقق عبر Zod (مخططات الجلسات)', () => {
  it('يقبل إنشاء جلسة صالحًا ويرفض القيم الفارغة والمجهولة', () => {
    expect(
      createSessionSchema.safeParse({ studentId: 's1', subjectId: 'mathematics' }).success,
    ).toBe(true);
    expect(createSessionSchema.safeParse({ studentId: '', subjectId: 'mathematics' }).success).toBe(false);
    expect(createSessionSchema.safeParse({ studentId: '   ', subjectId: 'mathematics' }).success).toBe(false);
    expect(createSessionSchema.safeParse({ studentId: 's1', subjectId: '' }).success).toBe(false);
    expect(createSessionSchema.safeParse({ studentId: 's1', subjectId: 'biology' }).success).toBe(false);
    // يقص المسافات حول القيم الصالحة.
    const padded = createSessionSchema.safeParse({ studentId: ' s1 ', subjectId: ' mathematics ' });
    expect(padded.success).toBe(true);
    if (padded.success) {
      expect(padded.data.subjectId).toBe('mathematics');
      expect(padded.data.studentId).toBe('s1');
    }
  });

  it('يتحقق من معرّف الجلسة', () => {
    expect(sessionIdSchema.safeParse('session-12345').success).toBe(true);
    expect(sessionIdSchema.safeParse('short').success).toBe(false);
    expect(sessionIdSchema.safeParse('        ').success).toBe(false);
  });

  it('يتحقق من معرّف المادة القادم من الرابط', () => {
    expect(urlSubjectIdSchema.safeParse('physics').success).toBe(true);
    expect(urlSubjectIdSchema.safeParse(' physics ').success).toBe(true);
    expect(urlSubjectIdSchema.safeParse('nonsense').success).toBe(false);
    expect(urlSubjectIdSchema.safeParse('').success).toBe(false);
  });

  it('يتحقق من معرّف المادة ومعرف الطالب بشكل مستقل', () => {
    expect(subjectIdSchema.safeParse('arabic').success).toBe(true);
    expect(subjectIdSchema.safeParse('unknown').success).toBe(false);
    expect(studentIdSchema.safeParse('student-1').success).toBe(true);
    expect(studentIdSchema.safeParse('  ').success).toBe(false);
  });
});
