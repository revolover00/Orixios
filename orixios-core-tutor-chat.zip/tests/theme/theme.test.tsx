// @vitest-environment happy-dom
/**
 * اختبارات نظام الثيمات: الداكن الافتراضي، التبديل، الحفظ والاستعادة،
 * وضع النظام، وسلوك زر التبديل — دون أي استدعاء خارجي.
 */

import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { cleanup, fireEvent, render, screen } from '@testing-library/react';
import { ThemeToggle } from '@/components/theme/theme-toggle';
import {
  applyTheme,
  getStoredThemeMode,
  resolveIsDark,
  setThemeMode,
  THEME_STORAGE_KEY,
} from '@/lib/theme/theme-mode';

function stubMatchMedia(prefersDark: boolean): void {
  const media = {
    matches: prefersDark,
    media: '(prefers-color-scheme: dark)',
    addEventListener: vi.fn(),
    removeEventListener: vi.fn(),
    addListener: vi.fn(),
    removeListener: vi.fn(),
    onchange: null,
    dispatchEvent: () => false,
  };
  vi.stubGlobal('matchMedia', vi.fn(() => media));
}

beforeEach(() => {
  window.localStorage.clear();
  document.documentElement.classList.remove('dark');
});

afterEach(() => {
  cleanup();
  vi.unstubAllGlobals();
});

describe('الوضع الافتراضي والحفظ', () => {
  it('الوضع الداكن هو الافتراضي عند غياب الاختيار', () => {
    expect(getStoredThemeMode()).toBe('dark');

    applyTheme('dark');
    expect(document.documentElement.classList.contains('dark')).toBe(true);
  });

  it('التبديل إلى الفاتح يزيل الصنف ويحفظ الاختيار', () => {
    setThemeMode('light');

    expect(document.documentElement.classList.contains('dark')).toBe(false);
    expect(window.localStorage.getItem(THEME_STORAGE_KEY)).toBe('light');
  });

  it('يحفظ الثيم ويستعيده', () => {
    setThemeMode('light');
    expect(getStoredThemeMode()).toBe('light');

    setThemeMode('dark');
    expect(getStoredThemeMode()).toBe('dark');

    setThemeMode('system');
    expect(getStoredThemeMode()).toBe('system');
  });

  it('يتجاهل قيمة تالفة في التخزين ويعود للافتراضي', () => {
    window.localStorage.setItem(THEME_STORAGE_KEY, 'قيمة-تالفة');
    expect(getStoredThemeMode()).toBe('dark');
  });
});

describe('وضع النظام', () => {
  it('يتبع تفضيل النظام عندما يكون الوضع system', () => {
    stubMatchMedia(true);
    expect(resolveIsDark('system')).toBe(true);

    stubMatchMedia(false);
    expect(resolveIsDark('system')).toBe(false);
  });

  it('يطبق وضع النظام على عنصر الجذر', () => {
    stubMatchMedia(false);
    setThemeMode('system');
    expect(document.documentElement.classList.contains('dark')).toBe(false);

    stubMatchMedia(true);
    applyTheme('system');
    expect(document.documentElement.classList.contains('dark')).toBe(true);
  });
});

describe('زر التبديل', () => {
  it('يعرض تسمية واضحة ويتنقل بين الأوضاع بالضغط', () => {
    render(<ThemeToggle />);

    const button = screen.getByRole('button');
    expect(button.getAttribute('aria-label')).toContain('داكن');

    // داكن ← فاتح
    fireEvent.click(button);
    expect(window.localStorage.getItem(THEME_STORAGE_KEY)).toBe('light');
    expect(document.documentElement.classList.contains('dark')).toBe(false);

    // فاتح ← نظام
    fireEvent.click(button);
    expect(window.localStorage.getItem(THEME_STORAGE_KEY)).toBe('system');

    // نظام ← داكن
    fireEvent.click(button);
    expect(window.localStorage.getItem(THEME_STORAGE_KEY)).toBe('dark');
    expect(document.documentElement.classList.contains('dark')).toBe(true);
  });

  it('يعمل بلوحة المفاتيح (زر حقيقي قابل للتركيز)', () => {
    render(<ThemeToggle />);

    const button = screen.getByRole('button') as HTMLButtonElement;
    button.focus();
    expect(document.activeElement).toBe(button);

    // Enter على الزر الحقيقي يطلق النقر في المتصفح؛ نحاكي النتيجة هنا.
    fireEvent.keyDown(button, { key: 'Enter' });
    fireEvent.click(button);
    expect(getStoredThemeMode()).toBe('light');
  });

  it('لا يعتمد على إيموجي وله نص بديل لقارئ الشاشة', () => {
    render(<ThemeToggle />);

    const button = screen.getByRole('button');
    expect(button.textContent).not.toMatch(/[\u{1F300}-\u{1FAFF}]/u);
    expect(button.querySelector('svg[aria-hidden="true"]')).toBeTruthy();
  });
});
