// @vitest-environment happy-dom
/**
 * اختبارات واجهة شات المدرّس باستخدام مزيفات فقط:
 * لا يُستدعى أي API خارجي، وكل استجابات الشبكة مُحقنة.
 */

import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { act, cleanup, fireEvent, render, screen, waitFor } from '@testing-library/react';
import { TutorChat } from '@/components/tutor/tutor-chat';
import { addApiKey } from '@/lib/ai-providers/user-keys-storage';
import { encodeSseEvent, type TutorStreamEvent } from '@/lib/tutor/tutor-stream';
import type { Subject } from '@/types/sessions';

// ضمان وجود جدولة الإطارات في بيئة الاختبار.
if (typeof globalThis.requestAnimationFrame !== 'function') {
  vi.stubGlobal(
    'requestAnimationFrame',
    (callback: (time: number) => void) => setTimeout(() => callback(0), 0),
  );
}

vi.mock('next/navigation', () => ({
  useRouter: () => ({ push: vi.fn() }),
}));

const MATH_SUBJECT: Subject = {
  id: 'mathematics',
  name: 'Mathematics',
  nameAr: 'الرياضيات',
  isActive: true,
};

const SESSION_OK = {
  success: true,
  data: { sessionId: 'session-ui-test-001', subjectId: 'mathematics', subjectName: 'الرياضيات' },
};

interface RecordedCall {
  url: string;
  body: Record<string, unknown> | null;
}

/**
 * محاكاة الشبكة: تحول الاستجابات القديمة إلى ما يفهمه مسار البث —
 * النجاح يصبح SSE (token ثم done)، والخطأ يبقى JSON موحدًا قبل البث.
 */
function installFetch(tutorResponse: () => unknown): { calls: RecordedCall[] } {
  const calls: RecordedCall[] = [];
  const implementation = async (input: RequestInfo | URL, init?: RequestInit) => {
    const url = typeof input === 'string' ? input : String(input);
    let body: Record<string, unknown> | null = null;
    if (typeof init?.body === 'string') {
      body = JSON.parse(init.body) as Record<string, unknown>;
    }
    calls.push({ url, body });
    if (url.includes('/api/sessions')) {
      return new Response(JSON.stringify(SESSION_OK), {
        headers: { 'Content-Type': 'application/json' },
      });
    }
    const payload = (await tutorResponse()) as {
      success?: boolean;
      data?: { message?: { content?: string } };
    };
    if (payload && payload.success === true) {
      const content = payload.data?.message?.content ?? '';
      const events: TutorStreamEvent[] = [
        { type: 'token', text: content },
        { type: 'done', keyStatusUpdates: [] },
      ];
      return new Response(events.map(encodeSseEvent).join(''), {
        headers: { 'Content-Type': 'text/event-stream' },
      });
    }
    return new Response(JSON.stringify(payload), {
      headers: { 'Content-Type': 'application/json' },
    });
  };
  vi.stubGlobal('fetch', implementation);
  return { calls };
}

function seedMockKey(): void {
  addApiKey({ provider: 'mock', label: 'مفتاح اختبار', apiKey: 'ui-test-mock-key-1' });
}

/**
 * محاكاة الشبكة لمسار البث: جلسات + استجابات SSE مرتبة لكل طلب شات.
 */
function installStreamFetch(tutorResponses: Array<() => Response>): {
  calls: Array<{ url: string; body: Record<string, unknown> | null }>;
} {
  const calls: Array<{ url: string; body: Record<string, unknown> | null }> = [];
  let tutorCallIndex = 0;
  const implementation = async (input: RequestInfo | URL, init?: RequestInit) => {
    const url = typeof input === 'string' ? input : String(input);
    let body: Record<string, unknown> | null = null;
    if (typeof init?.body === 'string') {
      body = JSON.parse(init.body) as Record<string, unknown>;
    }
    calls.push({ url, body });
    if (url.includes('/api/sessions')) {
      return { json: async () => SESSION_OK } as unknown as Response;
    }
    const factory = tutorResponses[Math.min(tutorCallIndex, tutorResponses.length - 1)];
    tutorCallIndex += 1;
    return factory();
  };
  vi.stubGlobal('fetch', implementation);
  return { calls };
}

function sseResponse(events: TutorStreamEvent[]): Response {
  const body = events.map(encodeSseEvent).join('');
  return new Response(body, {
    headers: { 'Content-Type': 'text/event-stream; charset=utf-8' },
  });
}

interface ControllableSse {
  response: Response;
  pushText: (text: string) => void;
  complete: (updates?: Array<{ keyId: string; status: 'active' | 'exhausted' | 'invalid' }>) => void;
}

/**
 * بث قابل للتحكم من الاختبار: يدفع أجزاءً عند الطلب، ويغلق عند
 * اكتمال البث أو عند إلغاء الإشارة (تمامًا كما يفعل المتصفح).
 */
function controllableSse(signal?: AbortSignal | null): ControllableSse {
  const encoder = new TextEncoder();
  const queue: Uint8Array[] = [];
  let waiting: ((result: { done: boolean; value?: Uint8Array }) => void) | null = null;
  let closed = false;

  const push = (bytes: Uint8Array) => {
    if (waiting) {
      const resolveWaiting = waiting;
      waiting = null;
      resolveWaiting({ done: false, value: bytes });
    } else {
      queue.push(bytes);
    }
  };
  const close = () => {
    closed = true;
    if (waiting) {
      const resolveWaiting = waiting;
      waiting = null;
      resolveWaiting({ done: true });
    }
  };
  signal?.addEventListener('abort', close);

  const reader = {
    read: () =>
      new Promise<{ done: boolean; value?: Uint8Array }>((resolve) => {
        const next = queue.shift();
        if (next) {
          resolve({ done: false, value: next });
          return;
        }
        if (closed) {
          resolve({ done: true });
          return;
        }
        waiting = resolve;
      }),
    releaseLock: () => {},
    cancel: async () => {},
  };

  const response = {
    headers: {
      get: (name: string) =>
        name.toLowerCase() === 'content-type' ? 'text/event-stream' : null,
    },
    body: { getReader: () => reader },
  } as unknown as Response;

  return {
    response,
    pushText: (text: string) => push(encoder.encode(encodeSseEvent({ type: 'token', text }))),
    complete: (updates = []) => {
      push(encoder.encode(encodeSseEvent({ type: 'done', keyStatusUpdates: updates })));
      close();
    },
  };
}

function installStoppableFetch(factory: (init?: RequestInit) => ControllableSse): void {
  const implementation = async (input: RequestInfo | URL, init?: RequestInit) => {
    const url = typeof input === 'string' ? input : String(input);
    if (url.includes('/api/sessions')) {
      return new Response(JSON.stringify(SESSION_OK), {
        headers: { 'Content-Type': 'application/json' },
      });
    }
    return factory(init).response;
  };
  vi.stubGlobal('fetch', implementation);
}

async function typeAndSend(text: string): Promise<void> {
  const textarea = screen.getByLabelText('رسالتك إلى المدرّس');
  fireEvent.change(textarea, { target: { value: text } });
  fireEvent.keyDown(textarea, { key: 'Enter' });
}

beforeEach(() => {
  window.localStorage.clear();
});

afterEach(() => {
  cleanup();
  vi.unstubAllGlobals();
});

describe('الحالات الأساسية', () => {
  it('يعرض الحالة الفارغة عند عدم وجود رسائل', () => {
    installFetch(() => ({ success: false }));
    seedMockKey();

    render(<TutorChat subject={MATH_SUBJECT} />);

    expect(screen.getByText('إزاي أقدر أساعدك النهارده؟')).toBeTruthy();
    expect(screen.getByText(/هنمشي مع بعض خطوة بخطوة/)).toBeTruthy();
    // عنوان الجلسة يعرض اسم المادة من المصدر الموثوق (الكتالوج).
    expect(screen.getByText('جلسة مادة الرياضيات')).toBeTruthy();
  });

  it('يعرض رابط تغيير المادة نحو الرئيسية ولا يبدّل المادة داخل الجلسة', () => {
    installFetch(() => ({ success: false }));
    seedMockKey();

    render(<TutorChat subject={MATH_SUBJECT} />);

    const switchLink = screen.getByText('تغيير المادة') as HTMLAnchorElement;
    expect(switchLink.getAttribute('href')).toBe('/');
    // لا توجد أزرار مواد تبدّل المادة داخل الجلسة نفسها.
    expect(screen.queryByText('الفيزياء')).toBeNull();
  });

  it('يرسل رسالة صحيحة ويعرض فقاعة الطالب دون بيانات ممنوعة', async () => {
    const { calls } = installFetch(() => ({
      success: true,
      data: { message: { role: 'assistant', content: 'رد المدرّس ظهر هنا' } },
    }));
    seedMockKey();

    render(<TutorChat subject={MATH_SUBJECT} />);
    await typeAndSend('اشرح المعادلات الخطية');

    // فقاعة الطالب تظهر فورًا.
    expect(await screen.findByTestId('bubble-user')).toBeTruthy();
    expect(screen.getByText('اشرح المعادلات الخطية')).toBeTruthy();

    await waitFor(() => {
      expect(calls.some((call) => call.url.includes('/api/tutor'))).toBe(true);
    });

    const tutorCall = calls.find((call) => call.url.includes('/api/tutor'));
    expect(tutorCall?.body).toBeTruthy();
    const body = tutorCall?.body ?? {};
    expect(body.subjectId).toBe('mathematics');
    expect(body.sessionId).toBe('session-ui-test-001');
    // لا يُرسل اسم مادة من العميل، ولا رسائل نظام/مطوّر/أدوات.
    expect(body.subjectName).toBeUndefined();
    const messages = body.messages as Array<{ role: string }>;
    expect(messages.every((message) => message.role === 'user' || message.role === 'assistant')).toBe(true);
  });

  it('يعرض رد المدرّس فقط بعد نجاح الاستجابة', async () => {
    installFetch(() => ({
      success: true,
      data: { message: { role: 'assistant', content: 'خطوة بخطوة سنصل للفهم' } },
    }));
    seedMockKey();

    render(<TutorChat subject={MATH_SUBJECT} />);
    await typeAndSend('سؤالي الأول');

    const bubble = await screen.findByTestId('bubble-assistant');
    expect(bubble.textContent).toContain('خطوة بخطوة سنصل للفهم');
    // لا يظهر أي جزء من نظام التشغيل الداخلي أو سياق المصادر.
    expect(document.body.textContent).not.toContain('<<GROUNDED_SOURCES>>');
    expect(document.body.textContent).not.toContain('أنت «أوريكسوس»');
    expect(document.body.textContent).not.toContain('development-fixture');
    expect(document.querySelector('script')).toBeNull();
  });

  it('يمنع إرسال رسالة فارغة أو مسافات فقط', () => {
    const { calls } = installFetch(() => ({ success: true, data: { message: { role: 'assistant', content: 'رد' } } }));
    seedMockKey();

    render(<TutorChat subject={MATH_SUBJECT} />);

    const button = screen.getByLabelText('إرسال الرسالة');
    expect((button as HTMLButtonElement).disabled).toBe(true);

    const textarea = screen.getByLabelText('رسالتك إلى المدرّس');
    fireEvent.change(textarea, { target: { value: '     ' } });
    fireEvent.keyDown(textarea, { key: 'Enter' });

    expect(calls.filter((call) => call.url.includes('/api/tutor'))).toHaveLength(0);
  });

  it('يعرض مؤشر التفكير أثناء الطلب ويمنع الإرسال المزدوج', async () => {
    let resolveTutor: (value: unknown) => void = () => {};
    const pending = new Promise((resolve) => {
      resolveTutor = resolve;
    });
    const { calls } = installFetch(() => pending);
    seedMockKey();

    render(<TutorChat subject={MATH_SUBJECT} />);
    await typeAndSend('سؤال قيد الانتظار');

    // مؤشر التفكير ظاهر أثناء التنفيذ.
    expect(await screen.findByText('المدرّس يفكر')).toBeTruthy();

    // الإدخال معطّل أثناء الإرسال (منع الإرسال المزدوج)، ويظهر زر الإيقاف بدل الإرسال.
    expect((screen.getByLabelText('رسالتك إلى المدرّس') as HTMLTextAreaElement).disabled).toBe(true);
    expect(screen.getByLabelText('إيقاف الرد')).toBeTruthy();
    expect(screen.queryByLabelText('إرسال الرسالة')).toBeNull();

    resolveTutor({ success: true, data: { message: { role: 'assistant', content: 'تم الرد' } } });

    await waitFor(() => {
      expect(screen.getByText('تم الرد')).toBeTruthy();
    });
    // طلب واحد فقط إلى /api/tutor رغم كل التفاعلات.
    expect(calls.filter((call) => call.url.includes('/api/tutor'))).toHaveLength(1);
  });
});

describe('الفشل وإعادة المحاولة', () => {
  it('يحتفظ برسالة الطالب عند الفشل ويعرض إعادة المحاولة للخطأ القابل للتكرار', async () => {
    let attempt = 0;
    installFetch(() => {
      attempt += 1;
      if (attempt === 1) {
        return {
          success: false,
          error: { code: 'NETWORK_ERROR', message: 'تعذر الاتصال بالمزود.', retryable: true },
        };
      }
      return { success: true, data: { message: { role: 'assistant', content: 'وصل الرد أخيرًا' } } };
    });
    seedMockKey();

    render(<TutorChat subject={MATH_SUBJECT} />);
    await typeAndSend('سؤال مهم');

    // الرسالة باقية بعد الفشل مع علامة الفشل، ولم تُضف رسالة مساعد.
    expect(await screen.findByText('لم تُرسل هذه الرسالة')).toBeTruthy();
    expect(screen.getByText('سؤال مهم')).toBeTruthy();
    expect(screen.queryByTestId('bubble-assistant')).toBeNull();

    // زر إعادة المحاولة ظاهر للخطأ القابل للتكرار.
    const retryButton = screen.getByText('إعادة المحاولة');
    fireEvent.click(retryButton);

    // بعد النجاح: بلا مضاعفة للرسائل، ورسالة المساعد وصلت.
    await waitFor(() => {
      expect(screen.getByText('وصل الرد أخيرًا')).toBeTruthy();
    });
    expect(screen.getAllByText('سؤال مهم')).toHaveLength(1);
    expect(screen.queryByText('لم تُرسل هذه الرسالة')).toBeNull();
  });

  it('يعرض خطأ غير قابل للتكرار بدون زر إعادة محاولة', async () => {
    installFetch(() => ({
      success: false,
      error: { code: 'INVALID_API_KEY', message: 'المفتاح غير صالح.', retryable: false },
    }));
    seedMockKey();

    render(<TutorChat subject={MATH_SUBJECT} />);
    await typeAndSend('سؤال');

    expect(await screen.findByText('المفتاح غير صالح.')).toBeTruthy();
    expect(screen.queryByText('إعادة المحاولة')).toBeNull();
  });
});

describe('حالات القفل والجلسة', () => {
  it('يعرض توجيه صفحة المفاتيح عند NO_API_KEY ولا يرسل أي طلب', () => {
    const { calls } = installFetch(() => ({ success: true, data: { message: { role: 'assistant', content: 'رد' } } }));
    // بلا أي مفاتيح في التخزين.

    render(<TutorChat subject={MATH_SUBJECT} />);

    expect(screen.getByText('لا يوجد مفتاح للبدء')).toBeTruthy();
    const link = screen.getByText('إدارة المفاتيح') as HTMLAnchorElement;
    expect(link.getAttribute('href')).toBe('/settings/api-keys');
    expect(screen.queryByLabelText('رسالتك إلى المدرّس')).toBeNull();
    expect(calls).toHaveLength(0);
  });

  it('يعرض حالة الجلسة المنتهية عند SESSION_ENDED', async () => {
    installFetch(() => ({
      success: false,
      error: { code: 'SESSION_ENDED', message: 'الجلسة منتهية.', retryable: false },
    }));
    seedMockKey();

    render(<TutorChat subject={MATH_SUBJECT} />);
    await typeAndSend('سؤال بعد انتهاء الجلسة');

    expect(await screen.findByText('انتهت هذه الجلسة')).toBeTruthy();
    // زر بدء جلسة جديدة متاح بدل محاولة تغيير المادة.
    expect(screen.getByText('بدء جلسة جديدة')).toBeTruthy();
    expect(screen.queryByLabelText('رسالتك إلى المدرّس')).toBeNull();
  });

  it('يعرض حالة فشل تحميل الجلسة مع إمكانية إعادة المحاولة', async () => {
    // فشل إنشاء الجلسة ثم نجاحها بعد إعادة المحاولة.
    let sessionAttempts = 0;
    const implementation = async (input: RequestInfo | URL, init?: RequestInit) => {
      const url = typeof input === 'string' ? input : String(input);
      if (url.includes('/api/sessions')) {
        sessionAttempts += 1;
        if (sessionAttempts === 1) {
          return { json: async () => ({ success: false }) } as unknown as Response;
        }
        return { json: async () => SESSION_OK } as unknown as Response;
      }
      void init;
      return new Response(
        encodeSseEvent({ type: 'token', text: 'رد بعد إعادة التجهيز' }) +
          encodeSseEvent({ type: 'done', keyStatusUpdates: [] }),
        { headers: { 'Content-Type': 'text/event-stream' } },
      );
    };
    vi.stubGlobal('fetch', implementation);
    seedMockKey();

    render(<TutorChat subject={MATH_SUBJECT} />);
    await typeAndSend('محاولة أولى');

    expect(await screen.findByText('تعذر تحميل الجلسة')).toBeTruthy();

    fireEvent.click(screen.getByText('إعادة المحاولة'));
    await typeAndSend('محاولة ثانية');

    await waitFor(() => {
      expect(screen.getByText('رد بعد إعادة التجهيز')).toBeTruthy();
    });
  });

  it('حقل الإدخال يعمل في RTL مع تسمية واضحة ومنع تجاوز التحقق', () => {
    installFetch(() => ({ success: false }));
    seedMockKey();

    render(<TutorChat subject={MATH_SUBJECT} />);

    const textarea = screen.getByLabelText('رسالتك إلى المدرّس') as HTMLTextAreaElement;
    expect(textarea).toBeTruthy();
    expect(textarea.placeholder.length).toBeGreaterThan(0);
    // اتجاه الصفحة يظل عربيًا داخل الوثيقة.
    expect(document.documentElement.getAttribute('dir') ?? 'rtl').toBeTruthy();
    // زر الإرسال معطّل قبل كتابة أي محتوى.
    expect((screen.getByLabelText('إرسال الرسالة') as HTMLButtonElement).disabled).toBe(true);
  });
});

describe('البث التدريجي', () => {
  it('يعرض مؤشر التفكير قبل أول جزء ثم رسالة واحدة تتحدث تدريجيًا', async () => {
    installStreamFetch([
      () =>
        sseResponse([
          { type: 'token', text: 'سنبدأ ' },
          { type: 'token', text: 'بخطوة صغيرة' },
          { type: 'done', keyStatusUpdates: [] },
        ]),
    ]);
    seedMockKey();

    render(<TutorChat subject={MATH_SUBJECT} />);
    await typeAndSend('اشرح المعادلات');

    // مؤشر التفكير حاضر قبل وصول أي جزء.
    expect(await screen.findByText('المدرّس يفكر')).toBeTruthy();

    // بعد اكتمال البث: فقاعة مساعد واحدة بالنص الكامل، وبلا مؤشر.
    await waitFor(
      () => {
        const bubble = screen.getByTestId('bubble-assistant');
        expect(bubble.textContent).toContain('سنبدأ بخطوة صغيرة');
      },
      { timeout: 3000 },
    );
    expect(screen.queryByText('المدرّس يفكر')).toBeNull();
    expect(screen.getAllByTestId('bubble-assistant')).toHaveLength(1);
    // رسالة الطالب اكتملت (لا توجد علامة إرسال أو فشل).
    expect(screen.queryByText('قيد الإرسال...')).toBeNull();
  });

  it('يظهر النص العربي سليمًا عند اكتمال البث', async () => {
    installStreamFetch([
      () =>
        sseResponse([
          { type: 'token', text: 'المعادلات ' },
          { type: 'token', text: 'الخطية تُحل خطوة بخطوة' },
          { type: 'done', keyStatusUpdates: [] },
        ]),
    ]);
    seedMockKey();

    render(<TutorChat subject={MATH_SUBJECT} />);
    await typeAndSend('سؤال عربي');

    await waitFor(
      () => {
        expect(screen.getByText('المعادلات الخطية تُحل خطوة بخطوة')).toBeTruthy();
      },
      { timeout: 3000 },
    );
  });

  it('يحتفظ بالنص الجزئي عند خطأ أثناء البث ويعرض إعادة المحاولة', async () => {
    installStreamFetch([
      () =>
        sseResponse([
          { type: 'token', text: 'بداية الرد ' },
          {
            type: 'error',
            code: 'NETWORK_ERROR',
            message: 'انقطع الاتصال بالمزود.',
            retryable: true,
            keyStatusUpdates: [],
          },
        ]),
      () =>
        sseResponse([
          { type: 'token', text: 'الرد الكامل بعد الإعادة' },
          { type: 'done', keyStatusUpdates: [] },
        ]),
    ]);
    seedMockKey();

    render(<TutorChat subject={MATH_SUBJECT} />);
    await typeAndSend('سؤال مهم');

    // النص الجزئي باقٍ مع علامة الرد غير المكتمل.
    await waitFor(() => {
      expect(screen.getByText('الرد غير مكتمل — يمكنك إعادة المحاولة')).toBeTruthy();
    });
    expect(screen.getByTestId('bubble-assistant').textContent).toContain('بداية الرد');
    // رسالة الطالب باقية بلا تكرار.
    expect(screen.getAllByText('سؤال مهم')).toHaveLength(1);

    // إعادة المحاولة: طلب ثانٍ يكمل المحادثة دون مضاعفة رسالة الطالب.
    fireEvent.click(screen.getByText('إعادة المحاولة'));

    await waitFor(
      () => {
        expect(screen.getByText('الرد الكامل بعد الإعادة')).toBeTruthy();
      },
      { timeout: 3000 },
    );
    expect(screen.getAllByText('سؤال مهم')).toHaveLength(1);
    expect(screen.queryByText('الرد غير مكتمل — يمكنك إعادة المحاولة')).toBeNull();
  });

  it('يمنع الإرسال المزدوج أثناء البث', async () => {
    installStreamFetch([
      () =>
        sseResponse([
          { type: 'token', text: 'رد' },
          { type: 'done', keyStatusUpdates: [] },
        ]),
    ]);
    seedMockKey();

    render(<TutorChat subject={MATH_SUBJECT} />);
    await typeAndSend('سؤال أول');

    // أثناء البث: الإدخال معطّل ويحل زر الإيقاف محل زر الإرسال.
    expect((screen.getByLabelText('رسالتك إلى المدرّس') as HTMLTextAreaElement).disabled).toBe(true);
    expect(screen.getByLabelText('إيقاف الرد')).toBeTruthy();
    expect(screen.queryByLabelText('إرسال الرسالة')).toBeNull();

    await waitFor(() => {
      expect(screen.getByTestId('bubble-assistant')).toBeTruthy();
    });
  });

  it('لا يعرض نظام الأوامر ولا السياق الموثوق ولا بيانات داخلية أثناء البث', async () => {
    installStreamFetch([
      () =>
        sseResponse([
          { type: 'token', text: 'شرح آمن فقط' },
          { type: 'done', keyStatusUpdates: [] },
        ]),
    ]);
    seedMockKey();

    render(<TutorChat subject={MATH_SUBJECT} />);
    await typeAndSend('سؤال');

    await waitFor(() => {
      expect(screen.getByText('شرح آمن فقط')).toBeTruthy();
    });
    const visibleText = document.body.textContent ?? '';
    expect(visibleText).not.toContain('<<GROUNDED_SOURCES>>');
    expect(visibleText).not.toContain('أنت «أوريكسوس»');
    expect(visibleText).not.toContain('ui-test-mock-key');
  });

  it('يعالج خطأ موحدًا قبل بدء البث داخل المسار التدفقي', async () => {
    installStreamFetch([
      () =>
        new Response(
          JSON.stringify({
            success: false,
            error: { code: 'INVALID_API_KEY', message: 'المفتاح غير صالح.', retryable: false },
            keyStatusUpdates: [{ keyId: 'x', status: 'invalid' }],
          }),
          { status: 401, headers: { 'Content-Type': 'application/json' } },
        ),
    ]);
    seedMockKey();

    render(<TutorChat subject={MATH_SUBJECT} />);
    await typeAndSend('سؤال بمفتاح سيئ');

    await waitFor(() => {
      expect(screen.getByText('المفتاح غير صالح.')).toBeTruthy();
    });
    // رابط مراجعة المفاتيح حاضر لهذه الحالة.
    expect(screen.getByText('مراجعة المفاتيح')).toBeTruthy();
    // لم تُنشأ رسالة مساعد فارغة قبل وصول أي نص.
    expect(screen.queryByTestId('bubble-assistant')).toBeNull();
  });
});

describe('إيقاف البث', () => {
  let abortSpy: ReturnType<typeof vi.spyOn>;

  beforeEach(() => {
    abortSpy = vi.spyOn(AbortController.prototype, 'abort');
  });

  afterEach(() => {
    abortSpy.mockRestore();
  });

  it('يظهر زر الإيقاف أثناء البث ويختفي بعد الاكتمال', async () => {
    let ctl: ControllableSse | null = null;
    installStoppableFetch((init) => {
      ctl = controllableSse(init?.signal);
      return ctl;
    });
    seedMockKey();

    render(<TutorChat subject={MATH_SUBJECT} />);
    await typeAndSend('سؤال للبث');

    // الزر حاضر أثناء معالجة الطلب (قبل أول جزء).
    expect(await screen.findByLabelText('إيقاف الرد')).toBeTruthy();
    // انتظار تأسيس طلب البث قبل دفع الأجزاء.
    await waitFor(() => {
      expect(ctl).not.toBeNull();
    });

    // دفع أول جزء: يختفي مؤشر التفكير وتظهر الفقاعة.
    await act(async () => {
      ctl?.pushText('جزء أول');
    });
    await waitFor(() => {
      expect(screen.getByTestId('bubble-assistant').textContent).toContain('جزء أول');
    });
    expect(screen.queryByText('المدرّس يفكر')).toBeNull();
    expect(screen.getByLabelText('إيقاف الرد')).toBeTruthy();

    // اكتمال البث: يختفي زر الإيقاف ويعود الإرسال دون حالة فشل.
    await act(async () => {
      ctl?.complete();
    });
    await waitFor(() => {
      expect(screen.queryByLabelText('إيقاف الرد')).toBeNull();
    });
    expect(screen.queryByText('الرد غير مكتمل — يمكنك إعادة المحاولة')).toBeNull();
    expect(screen.getByLabelText('إرسال الرسالة')).toBeTruthy();
  });

  it('يستدعي AbortController ويحتفظ بالنص الجزئي بعد الإلغاء', async () => {
    let ctl: ControllableSse | null = null;
    installStoppableFetch((init) => {
      ctl = controllableSse(init?.signal);
      return ctl;
    });
    seedMockKey();

    render(<TutorChat subject={MATH_SUBJECT} />);
    await typeAndSend('سؤال الإلغاء');

    // انتظار تأسيس طلب البث قبل دفع الأجزاء.
    await waitFor(() => {
      expect(ctl).not.toBeNull();
    });

    await act(async () => {
      ctl?.pushText('بداية الرد ');
    });
    await waitFor(() => {
      expect(screen.getByTestId('bubble-assistant').textContent).toContain('بداية الرد');
    });

    fireEvent.click(screen.getByLabelText('إيقاف الرد'));

    // استدعاء AbortController فعليًا.
    expect(abortSpy).toHaveBeenCalledTimes(1);

    await waitFor(() => {
      expect(screen.queryByLabelText('إيقاف الرد')).toBeNull();
    });

    // النص الجزئي باقٍ في نفس الفقاعة دون رسائل جديدة ودون حالة فشل.
    expect(screen.getAllByTestId('bubble-assistant')).toHaveLength(1);
    expect(screen.getByTestId('bubble-assistant').textContent).toContain('بداية الرد');
    expect(screen.queryByText('الرد غير مكتمل — يمكنك إعادة المحاولة')).toBeNull();
    expect(screen.queryByRole('alert')).toBeNull();
    // لا تسريب لقيمة المفتاح في الواجهة.
    expect(document.body.textContent).not.toContain('ui-test-mock-key');
    // الإدخال جاهز لرسالة جديدة.
    expect((screen.getByLabelText('رسالتك إلى المدرّس') as HTMLTextAreaElement).disabled).toBe(false);
  });

  it('الإيقاف قبل وصول أي نص لا ينشئ رسالة مساعد', async () => {
    let ctl: ControllableSse | null = null;
    installStoppableFetch((init) => {
      ctl = controllableSse(init?.signal);
      return ctl;
    });
    seedMockKey();

    render(<TutorChat subject={MATH_SUBJECT} />);
    await typeAndSend('سؤال مبكر');

    // لا تُدفع أي أجزاء: إيقاف مباشر أثناء الانتظار.
    const stopButton = await screen.findByLabelText('إيقاف الرد');
    fireEvent.click(stopButton);

    await waitFor(() => {
      expect(screen.queryByLabelText('إيقاف الرد')).toBeNull();
    });
    expect(screen.queryByTestId('bubble-assistant')).toBeNull();
    expect(screen.queryByText('قيد الإرسال...')).toBeNull();
    expect(screen.getByText('سؤال مبكر')).toBeTruthy();
    expect(abortSpy).toHaveBeenCalledTimes(1);
  });

  it('زر الإيقاف قابل للوصول بلوحة المفاتيح', async () => {
    let ctl: ControllableSse | null = null;
    installStoppableFetch((init) => {
      ctl = controllableSse(init?.signal);
      return ctl;
    });
    seedMockKey();

    render(<TutorChat subject={MATH_SUBJECT} />);
    await typeAndSend('سؤال الوصول');

    // انتظار تأسيس طلب البث قبل دفع الأجزاء.
    await waitFor(() => {
      expect(ctl).not.toBeNull();
    });

    await act(async () => {
      ctl?.pushText('نص');
    });
    const stopButton = (await screen.findByLabelText('إيقاف الرد')) as HTMLButtonElement;

    stopButton.focus();
    expect(document.activeElement).toBe(stopButton);
    expect(stopButton.getAttribute('aria-label')).toBe('إيقاف الرد');

    fireEvent.click(stopButton);
    await waitFor(() => {
      expect(screen.queryByLabelText('إيقاف الرد')).toBeNull();
    });
  });
});
