// @vitest-environment happy-dom
/**
 * اختبارات الهيكل العام: الشريط الجانبي على سطح المكتب،
 * وتحوله إلى Drawer على الهاتف، وبنية تمنع الفيض الأفقي.
 */

import { afterEach, describe, expect, it, vi } from 'vitest';
import { cleanup, fireEvent, render, screen } from '@testing-library/react';
import { AppShell } from '@/components/layout/app-shell';

vi.mock('next/navigation', () => ({
  usePathname: () => '/session/mathematics',
}));

afterEach(() => {
  cleanup();
});

describe('الهيكل العام', () => {
  it('يعرض الشريط الجانبي ثابتًا على سطح المكتب مع الروابط الأساسية', () => {
    render(<AppShell>محتوى</AppShell>);

    // الشريط الجانبي لسطح المكتب (مخفي على الهاتف عبر أصناف الاستجابة).
    const desktopAside = document.querySelector('aside.hidden.lg\\:block');
    expect(desktopAside).toBeTruthy();
    expect(desktopAside?.textContent).toContain('الرئيسية');
    expect(desktopAside?.textContent).toContain('مفاتيح المزودات');
    expect(desktopAside?.textContent).toContain('بدء محادثة جديدة');

    // المواد الأربع الحقيقية دون بيانات وهمية.
    for (const name of ['الرياضيات', 'الفيزياء', 'الكيمياء', 'اللغة العربية']) {
      expect(desktopAside?.textContent).toContain(name);
    }
  });

  it('يعرض حالة فارغة لسجل الجلسات بدل بيانات وهمية', () => {
    render(<AppShell>محتوى</AppShell>);

    expect(screen.getAllByText('لا يوجد سجل محفوظ للجلسات بعد.').length).toBeGreaterThan(0);
  });

  it('يعرض الجلسة الحالية عند وجودها في المسار', () => {
    render(<AppShell>محتوى</AppShell>);

    expect(screen.getAllByText('مادة الرياضيات').length).toBeGreaterThan(0);
  });

  it('رابط بدء محادثة جديدة يشير إلى الرئيسية', () => {
    render(<AppShell>محتوى</AppShell>);

    const links = Array.from(document.querySelectorAll('a[href="/"]'));
    expect(links.length).toBeGreaterThan(0);
  });
});

describe('الشريط الجانبي على الهاتف', () => {
  it('مخفي افتراضيًا ويفتح بزر القائمة ثم يغلق', () => {
    render(<AppShell>محتوى</AppShell>);

    // الدرج المحمول موجود لكن مخفي (aria-hidden) في البداية.
    const mobileAsides = Array.from(document.querySelectorAll('aside')).filter(
      (aside) => aside.className.includes('lg:hidden'),
    );
    expect(mobileAsides).toHaveLength(1);
    expect(mobileAsides[0]?.getAttribute('aria-hidden')).toBe('true');

    fireEvent.click(screen.getByLabelText('فتح القائمة'));
    expect(mobileAsides[0]?.getAttribute('aria-hidden')).toBe('false');

    fireEvent.click(screen.getAllByLabelText('إغلاق القائمة')[0]);
    expect(mobileAsides[0]?.getAttribute('aria-hidden')).toBe('true');
  });

  it('زر القائمة يظهر فقط في الشريط العلوي المخصص للهاتف', () => {
    render(<AppShell>محتوى</AppShell>);

    const menuButton = screen.getByLabelText('فتح القائمة');
    const header = menuButton.closest('header');
    expect(header?.className).toContain('lg:hidden');
  });
});

describe('بنية تمنع الفيض الأفقي', () => {
  it('منطقة المحتوى والمحادثة تستخدمان min-w-0 وoverflow مناسبين', () => {
    render(<AppShell>محتوى</AppShell>);

    const wrapper = document.querySelector('div.flex.min-w-0.flex-1.flex-col');
    expect(wrapper).toBeTruthy();
    const main = wrapper?.querySelector('main');
    expect(main?.className).toContain('min-h-0');
    expect(main?.className).toContain('overflow-y-auto');
  });
});
