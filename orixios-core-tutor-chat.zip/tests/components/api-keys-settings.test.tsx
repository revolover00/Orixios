// @vitest-environment happy-dom
/**
 * اختبارات صفحة إدارة المفاتيح باستخدام التخزين المحلي فقط (بدون شبكة).
 * لا تُستخدم أي مفاتيح حقيقية، وتُتحقق قواعد الإخفاء والأمان في الـ DOM.
 */

import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { cleanup, fireEvent, render, screen, waitFor } from '@testing-library/react';
import ApiKeysSettingsPage from '@/app/settings/api-keys/page';
import {
  addApiKey,
  listApiKeys,
  updateApiKeyStatus,
} from '@/lib/ai-providers/user-keys-storage';

beforeEach(() => {
  window.localStorage.clear();
});

afterEach(() => {
  cleanup();
  vi.unstubAllGlobals();
});

function fillAndSubmit(options: { provider?: string; label: string; apiKey: string }): void {
  if (options.provider) {
    fireEvent.change(screen.getByLabelText('المزود'), {
      target: { value: options.provider },
    });
  }
  fireEvent.change(screen.getByLabelText('اسم وصفي للمفتاح'), {
    target: { value: options.label },
  });
  fireEvent.change(screen.getByLabelText('قيمة المفتاح'), {
    target: { value: options.apiKey },
  });
  fireEvent.click(screen.getByText('حفظ المفتاح'));
}

describe('الحالة الأولية والتنبيه الأمني', () => {
  it('يعرض حالة عدم وجود مفاتيح وتنبيه التخزين التطويري', () => {
    render(<ApiKeysSettingsPage />);

    expect(screen.getByText('لا توجد مفاتيح محفوظة بعد')).toBeTruthy();
    expect(screen.getByText(/مناسب للتطوير فقط/)).toBeTruthy();
    expect(screen.getByText(/Supabase Vault/)).toBeTruthy();
  });
});

describe('إضافة مفتاح', () => {
  it('يضيف مفتاحًا صالحًا ويعرضه مقنعًا ويمسح الحقل', () => {
    render(<ApiKeysSettingsPage />);

    fillAndSubmit({ label: 'مفتاح المذاكرة', apiKey: 'ui-page-secret-value-77' });

    expect(screen.getByText('تم حفظ المفتاح. لن تظهر قيمته الكاملة بعد الآن.')).toBeTruthy();
    expect(screen.getByText('مفتاح المذاكرة')).toBeTruthy();
    // القيمة الكاملة لا تظهر في أي مكان في الوثيقة.
    expect(document.body.textContent).not.toContain('ui-page-secret-value-77');
    // تظهر معاينة مقنّعة بدلًا منها.
    expect(document.body.textContent).toContain('••••••••••');
    // حقل المفتاح مُسح بعد الحفظ.
    expect((screen.getByLabelText('قيمة المفتاح') as HTMLInputElement).value).toBe('');
    expect(listApiKeys()).toHaveLength(1);
  });

  it('يعرض خطأ عند تسمية فارغة ولا يضيف شيئًا', () => {
    render(<ApiKeysSettingsPage />);

    fillAndSubmit({ label: '   ', apiKey: 'ui-page-key-valid-11' });

    expect(document.body.textContent).toContain('التسمية مطلوبة');
    expect(listApiKeys()).toHaveLength(0);
  });

  it('يرفض تكرار نفس المفتاح برسالة لا تكشف القيمة', () => {
    render(<ApiKeysSettingsPage />);

    fillAndSubmit({ label: 'الأول', apiKey: 'ui-duplicate-key-33' });
    fillAndSubmit({ label: 'الثاني', apiKey: 'ui-duplicate-key-33' });

    expect(
      screen.getByText('يوجد مفتاح بنفس القيمة محفوظًا مسبقًا لهذا المزود.'),
    ).toBeTruthy();
    expect(document.body.textContent).not.toContain('ui-duplicate-key-33');
    expect(listApiKeys()).toHaveLength(1);
  });

  it('يعرض المزودات النائبة كخيارات معطلة ويمنع الحفظ لها', () => {
    render(<ApiKeysSettingsPage />);

    const options = Array.from(
      document.querySelectorAll('option'),
    ) as HTMLOptionElement[];
    const openrouter = options.find((option) => option.textContent?.includes('OpenRouter'));
    const githubModels = options.find((option) =>
      option.textContent?.includes('GitHub Models'),
    );

    expect(openrouter?.disabled).toBe(true);
    expect(openrouter?.textContent).toContain('غير متاح حاليًا');
    expect(githubModels?.disabled).toBe(true);
  });
});

describe('الافتراضية والحذف', () => {
  it('ينقل الافتراضية بين المفاتيح مع بقاء افتراضي واحد فقط', () => {
    const first = addApiKey({ provider: 'gemini', label: 'الأول', apiKey: 'ui-def-key-aaa' });
    addApiKey({ provider: 'gemini', label: 'الثاني', apiKey: 'ui-def-key-bbb' });

    render(<ApiKeysSettingsPage />);

    // الأول افتراضي في البداية.
    expect(screen.getAllByText('الافتراضي')).toHaveLength(1);

    // زر التعيين يظهر على البطاقة غير الافتراضية فقط.
    fireEvent.click(screen.getByText('تعيين كافتراضي'));

    expect(screen.getAllByText('الافتراضي')).toHaveLength(1);
    expect(listApiKeys().find((key) => key.id === first.id)?.isDefault).toBe(false);
  });

  it('يحذف مفتاحًا عبر مربع الحوار', () => {
    addApiKey({ provider: 'gemini', label: 'مفتاح للحذف', apiKey: 'ui-del-key-ccc' });

    render(<ApiKeysSettingsPage />);

    fireEvent.click(screen.getByLabelText('حذف المفتاح مفتاح للحذف'));

    // مربع الحوار يظهر بمعلومات مقنّعة فقط.
    expect(screen.getByRole('dialog')).toBeTruthy();
    expect(document.body.textContent).not.toContain('ui-del-key-ccc');

    fireEvent.click(screen.getByRole('button', { name: 'حذف المفتاح' }));

    expect(screen.getByText('لا توجد مفاتيح محفوظة بعد')).toBeTruthy();
    expect(listApiKeys()).toHaveLength(0);
  });

  it('حذف المفتاح الافتراضي يرقّي بديلًا ولا يكسر الواجهة', () => {
    addApiKey({ provider: 'gemini', label: 'الافتراضي القديم', apiKey: 'ui-del-key-ddd' });
    addApiKey({ provider: 'gemini', label: 'البديل', apiKey: 'ui-del-key-eee' });

    render(<ApiKeysSettingsPage />);

    fireEvent.click(screen.getByLabelText('حذف المفتاح الافتراضي القديم'));
    fireEvent.click(screen.getByRole('button', { name: 'حذف المفتاح' }));

    // المفتاح المتبقي أصبح افتراضيًا.
    expect(screen.getAllByText('الافتراضي')).toHaveLength(1);
    expect(screen.getByText('البديل')).toBeTruthy();
    expect(listApiKeys()[0]?.isDefault).toBe(true);
  });

  it('إلغاء مربع الحوار لا يحذف شيئًا', () => {
    addApiKey({ provider: 'gemini', label: 'باقٍ', apiKey: 'ui-keep-key-fff' });

    render(<ApiKeysSettingsPage />);

    fireEvent.click(screen.getByLabelText('حذف المفتاح باقٍ'));

    // نص البطاقة «باقٍ»؛ استخدم زر الإلغاء في الحوار.
    fireEvent.click(screen.getByRole('button', { name: 'إلغاء' }));

    expect(listApiKeys()).toHaveLength(1);
  });
});

describe('حالات المفاتيح', () => {
  it('يعرض حالات نشط ومستنفد وغير صالح مع إعادة تفعيل آمنة', async () => {
    addApiKey({ provider: 'gemini', label: 'مفتاح ألف', apiKey: 'ui-status-key-11' });
    const exhausted = addApiKey({
      provider: 'gemini',
      label: 'مفتاح باء',
      apiKey: 'ui-status-key-22',
    });
    const invalid = addApiKey({
      provider: 'gemini',
      label: 'مفتاح جيم',
      apiKey: 'ui-status-key-33',
    });
    updateApiKeyStatus(exhausted.id, 'exhausted');
    updateApiKeyStatus(invalid.id, 'invalid');

    render(<ApiKeysSettingsPage />);

    expect(screen.getByText('نشط')).toBeTruthy();
    expect(screen.getByText('مستنفد')).toBeTruthy();
    expect(screen.getByText('غير صالح')).toBeTruthy();

    // إعادة التعيين إلى نشط متاحة للمفاتيح غير النشطة فقط.
    const reactivateButtons = screen.getAllByText('إعادة التعيين إلى نشط');
    expect(reactivateButtons).toHaveLength(2);

    fireEvent.click(reactivateButtons[1]);

    await waitFor(() => {
      expect(listApiKeys().find((key) => key.id === invalid.id)?.status).toBe('active');
    });
  });

  it('يسمح بإعادة تسمية مفتاح قائم', () => {
    addApiKey({ provider: 'gemini', label: 'اسم سابق', apiKey: 'ui-rename-key-44' });

    render(<ApiKeysSettingsPage />);

    fireEvent.click(screen.getByText('إعادة تسمية'));
    fireEvent.change(screen.getByLabelText('التسمية الجديدة للمفتاح'), {
      target: { value: 'اسم محدث' },
    });
    fireEvent.click(screen.getByText('حفظ'));

    expect(screen.getByText('اسم محدث')).toBeTruthy();
    expect(listApiKeys()[0]?.label).toBe('اسم محدث');
  });
});
