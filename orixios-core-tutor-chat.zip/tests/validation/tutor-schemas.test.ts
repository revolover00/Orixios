import { describe, expect, it } from 'vitest';
import {
  addApiKeySchema,
  apiKeyFormSchema,
  providerNameSchema,
  selectKeySchema,
  selectProviderSchema,
  tutorChatRequestSchema,
} from '@/lib/validation/tutor-schemas';

const validBody = {
  sessionId: 'session-1234567890',
  subjectId: 'mathematics',
  messages: [{ role: 'user', content: 'اشرح لي المعادلات الخطية' }],
  keys: [],
};

describe('التحقق من جسم طلب الشات عبر Zod', () => {
  it('يقبل جسمًا صالحًا', () => {
    const parsed = tutorChatRequestSchema.safeParse(validBody);

    expect(parsed.success).toBe(true);
  });

  it('يرفض غياب sessionId', () => {
    const { sessionId: _sessionId, ...withoutSession } = validBody;
    const parsed = tutorChatRequestSchema.safeParse(withoutSession);

    expect(parsed.success).toBe(false);
  });

  it('يرفض مادة غير صالحة', () => {
    const parsed = tutorChatRequestSchema.safeParse({
      ...validBody,
      subjectId: 'biology',
    });

    expect(parsed.success).toBe(false);
  });

  it('يرفض قائمة رسائل فارغة', () => {
    const parsed = tutorChatRequestSchema.safeParse({
      ...validBody,
      messages: [],
    });

    expect(parsed.success).toBe(false);
  });

  it('يرفض رسالة فارغة المحتوى', () => {
    const parsed = tutorChatRequestSchema.safeParse({
      ...validBody,
      messages: [{ role: 'user', content: '   ' }],
    });

    expect(parsed.success).toBe(false);
  });

  it('يرفض مفتاحًا أقصر من الحد الأدنى', () => {
    const parsed = tutorChatRequestSchema.safeParse({
      ...validBody,
      keys: [{ id: 'k1', provider: 'gemini', apiKey: 'short' }],
    });

    expect(parsed.success).toBe(false);
  });

  it('يقبل currentTopic اختياريًا ويتجاهل الحقول الزائدة', () => {
    const parsed = tutorChatRequestSchema.safeParse({
      ...validBody,
      currentTopic: 'المعادلات الخطية',
    });

    expect(parsed.success).toBe(true);
    if (parsed.success) {
      expect(parsed.data.currentTopic).toBe('المعادلات الخطية');
      expect(parsed.data.keys).toEqual([]);
    }
  });
});

describe('التحقق من نموذج إضافة مفتاح', () => {
  it('يقبل نموذجًا صالحًا', () => {
    const parsed = addApiKeySchema.safeParse({
      provider: 'gemini',
      label: 'مفتاحي',
      apiKey: 'some-key-12345',
    });

    expect(parsed.success).toBe(true);
  });

  it('يرفض تسمية فارغة أو مسافات فقط', () => {
    expect(addApiKeySchema.safeParse({ provider: 'gemini', label: '', apiKey: 'some-key-12345' }).success).toBe(false);
    expect(addApiKeySchema.safeParse({ provider: 'gemini', label: '    ', apiKey: 'some-key-12345' }).success).toBe(false);
  });

  it('يرفض مفتاحًا قصيرًا جدًا أو مسافات فقط', () => {
    expect(addApiKeySchema.safeParse({ provider: 'gemini', label: 'مفتاحي', apiKey: 'abc' }).success).toBe(false);
    expect(addApiKeySchema.safeParse({ provider: 'gemini', label: 'مفتاحي', apiKey: '          ' }).success).toBe(false);
  });

  it('يرفض مزودًا خارج القائمة المسموحة', () => {
    const parsed = addApiKeySchema.safeParse({
      provider: 'nvidia',
      label: 'مفتاحي',
      apiKey: 'some-key-12345',
    });

    expect(parsed.success).toBe(false);
  });
});

describe('مخطط نموذج إضافة مفتاح مع إتاحة المزودين', () => {
  it('يقبل المزودين المفعّلين فقط', () => {
    expect(
      apiKeyFormSchema.safeParse({ provider: 'gemini', label: 'مفتاحي', apiKey: 'some-key-12345' })
        .success,
    ).toBe(true);
    expect(
      apiKeyFormSchema.safeParse({ provider: 'mock', label: 'محاكاة', apiKey: 'some-key-12345' })
        .success,
    ).toBe(true);
  });

  it('يرفض حفظ مفتاح لمزود غير مفعّل (عناصر نائبة)', () => {
    for (const provider of ['openrouter', 'github-models']) {
      const parsed = apiKeyFormSchema.safeParse({
        provider,
        label: 'مفتاحي',
        apiKey: 'some-key-12345',
      });
      expect(parsed.success, `provider: ${provider}`).toBe(false);
    }
  });

  it('يرفض التسمية الفارغة والمفتاح الفارغ والمسافات فقط', () => {
    expect(
      apiKeyFormSchema.safeParse({ provider: 'gemini', label: '   ', apiKey: 'some-key-12345' })
        .success,
    ).toBe(false);
    expect(
      apiKeyFormSchema.safeParse({ provider: 'gemini', label: 'مفتاحي', apiKey: '      ' })
        .success,
    ).toBe(false);
    expect(
      apiKeyFormSchema.safeParse({ provider: 'gemini', label: 'مفتاحي', apiKey: 'short' })
        .success,
    ).toBe(false);
  });
});

describe('التحقق من اختيار مفتاح ومزود', () => {
  it('يتطلب keyId غير فارغ', () => {
    expect(selectKeySchema.safeParse({ keyId: 'key-123' }).success).toBe(true);
    expect(selectKeySchema.safeParse({ keyId: '' }).success).toBe(false);
    expect(selectKeySchema.safeParse({ keyId: '   ' }).success).toBe(false);
    expect(selectKeySchema.safeParse({}).success).toBe(false);
  });

  it('يتحقق من اسم المزود', () => {
    expect(providerNameSchema.safeParse('gemini').success).toBe(true);
    expect(providerNameSchema.safeParse('openrouter').success).toBe(true);
    expect(providerNameSchema.safeParse('github-models').success).toBe(true);
    expect(providerNameSchema.safeParse('nvidia').success).toBe(false);
  });

  it('يتحقق من اختيار مزود كامل', () => {
    expect(selectProviderSchema.safeParse({ provider: 'gemini' }).success).toBe(true);
    expect(selectProviderSchema.safeParse({ provider: 'unknown' }).success).toBe(false);
  });
});
