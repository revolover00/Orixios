import { beforeEach, describe, expect, it, vi } from 'vitest';
import {
  parseTutorApiResponse,
  postCreateSession,
  postTutorChat,
  TutorClientError,
} from '@/lib/tutor/tutor-client';

function jsonResponse(payload: unknown): Response {
  return { json: async () => payload } as unknown as Response;
}

describe('parseTutorApiResponse — التحقق قبل الاستخدام', () => {
  it('يقبل استجابة نجاح صالحة كاملة', () => {
    const parsed = parseTutorApiResponse({
      success: true,
      data: {
        message: { role: 'assistant', content: 'رد المدرّس' },
        reasoning: 'تفكير داخلي',
        usage: { inputTokens: 10, outputTokens: 5 },
      },
      keyStatusUpdates: [{ keyId: 'k1', status: 'exhausted' }],
    });

    expect(parsed).not.toBeNull();
    if (parsed?.success) {
      expect(parsed.data.message.role).toBe('assistant');
      expect(parsed.data.message.content).toBe('رد المدرّس');
      expect(parsed.data.usage?.inputTokens).toBe(10);
    }
    expect(parsed?.keyStatusUpdates).toEqual([{ keyId: 'k1', status: 'exhausted' }]);
  });

  it('يرفض دور مساعد غير صحيح أو محتوى غير نصي', () => {
    expect(
      parseTutorApiResponse({
        success: true,
        data: { message: { role: 'system', content: 'حقن' } },
      }),
    ).toBeNull();
    expect(
      parseTutorApiResponse({ success: true, data: { message: { role: 'assistant', content: 5 } } }),
    ).toBeNull();
    expect(parseTutorApiResponse({ success: true })).toBeNull();
  });

  it('يقبل استجابة خطأ صالحة ويجبر retryable على قيمة منطقية', () => {
    const parsed = parseTutorApiResponse({
      success: false,
      error: { code: 'NETWORK_ERROR', message: 'خطأ', retryable: 'yes' },
    });

    expect(parsed).not.toBeNull();
    if (parsed && !parsed.success) {
      expect(parsed.error.code).toBe('NETWORK_ERROR');
      expect(parsed.error.retryable).toBe(false);
    }
  });

  it('يرفض الأشكال غير المتوقعة تمامًا', () => {
    expect(parseTutorApiResponse(null)).toBeNull();
    expect(parseTutorApiResponse('نص')).toBeNull();
    expect(parseTutorApiResponse({ success: 'true' })).toBeNull();
    expect(parseTutorApiResponse({ success: false })).toBeNull();
    expect(parseTutorApiResponse({ success: false, error: { code: 1 } })).toBeNull();
  });

  it('يستبعد تحديثات المفاتيح غير الصالحة دون كسر الاستجابة', () => {
    const parsed = parseTutorApiResponse({
      success: true,
      data: { message: { role: 'assistant', content: 'رد' } },
      keyStatusUpdates: [
        { keyId: '', status: 'active' },
        { keyId: 'k2', status: 'حالة-غريبة' },
        { keyId: 'k3', status: 'invalid' },
        'مدخل غريب',
      ],
    });

    expect(parsed?.keyStatusUpdates).toEqual([{ keyId: 'k3', status: 'invalid' }]);
  });
});

describe('postTutorChat', () => {
  beforeEach(() => {
    vi.unstubAllGlobals();
  });

  const payload = {
    sessionId: 'session-12345678',
    subjectId: 'mathematics',
    messages: [{ role: 'user' as const, content: 'سؤال' }],
    keys: [],
  };

  it('يعيد استجابة ناجحة بعد التحقق منها', async () => {
    const fetchMock = vi.fn(async () =>
      jsonResponse({
        success: true,
        data: { message: { role: 'assistant', content: 'أهلًا' } },
      }),
    );
    vi.stubGlobal('fetch', fetchMock);

    const response = await postTutorChat(payload);

    expect(response.success).toBe(true);
  });

  it('يرمي TutorClientError عند فشل الشبكة', async () => {
    const fetchMock = vi.fn(async () => {
      throw new Error('boom');
    });
    vi.stubGlobal('fetch', fetchMock);

    await expect(postTutorChat(payload)).rejects.toThrowError(TutorClientError);
  });

  it('يرمي TutorClientError لاستجابة غير صالحة بدل تمريرها', async () => {
    const fetchMock = vi.fn(async () => jsonResponse({ unexpected: true }));
    vi.stubGlobal('fetch', fetchMock);

    await expect(postTutorChat(payload)).rejects.toThrowError(TutorClientError);
  });
});

describe('postCreateSession', () => {
  beforeEach(() => {
    vi.unstubAllGlobals();
  });

  it('يعيد بيانات الجلسة عند نجاح الإنشاء', async () => {
    const fetchMock = vi.fn(async () =>
      jsonResponse({
        success: true,
        data: { sessionId: 's-1', subjectId: 'mathematics', subjectName: 'الرياضيات' },
      }),
    );
    vi.stubGlobal('fetch', fetchMock);

    const result = await postCreateSession('mathematics');

    expect(result?.sessionId).toBe('s-1');
    expect(result?.subjectName).toBe('الرياضيات');
  });

  it('يعيد null عند الفشل أو الشكل غير الصالح دون رمي خطأ', async () => {
    vi.stubGlobal('fetch', vi.fn(async () => jsonResponse({ success: false })));
    expect(await postCreateSession('mathematics')).toBeNull();

    vi.stubGlobal('fetch', vi.fn(async () => jsonResponse({ success: true, data: { sessionId: 5 } })));
    expect(await postCreateSession('mathematics')).toBeNull();

    vi.stubGlobal(
      'fetch',
      vi.fn(async () => {
        throw new Error('network');
      }),
    );
    expect(await postCreateSession('mathematics')).toBeNull();
  });
});
