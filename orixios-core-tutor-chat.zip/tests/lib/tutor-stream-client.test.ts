/**
 * اختبارات بروتوكول البث وطبقة العميل التدفقية.
 * تُبنى الاستجابات محليًا (بدون أي شبكة حقيقية).
 */

import { afterEach, describe, expect, it, vi } from 'vitest';
import {
  streamTutorChat,
  TutorClientError,
  type TutorChatPayload,
} from '@/lib/tutor/tutor-client';
import { encodeSseEvent, parseSseBlock, type TutorStreamEvent } from '@/lib/tutor/tutor-stream';

const PAYLOAD: TutorChatPayload = {
  sessionId: 'session-12345678',
  subjectId: 'mathematics',
  messages: [{ role: 'user', content: 'سؤال' }],
  keys: [],
};

function sseResponse(events: TutorStreamEvent[]): Response {
  const body = events.map(encodeSseEvent).join('');
  return new Response(body, {
    headers: { 'Content-Type': 'text/event-stream; charset=utf-8' },
  });
}

afterEach(() => {
  vi.unstubAllGlobals();
});

describe('parseSseBlock — التحقق قبل الاستخدام', () => {
  it('يحلل أحداث token وdone وerror الصالحة', () => {
    const token = parseSseBlock('event: token\ndata: {"text":"مرحبا"}');
    expect(token).toEqual({ type: 'token', text: 'مرحبا' });

    const done = parseSseBlock(
      'event: done\ndata: {"usage":{"outputTokens":3},"keyStatusUpdates":[{"keyId":"k1","status":"exhausted"}]}',
    );
    expect(done?.type).toBe('done');
    if (done?.type === 'done') {
      expect(done.usage?.outputTokens).toBe(3);
      expect(done.keyStatusUpdates).toEqual([{ keyId: 'k1', status: 'exhausted' }]);
    }

    const error = parseSseBlock(
      'event: error\ndata: {"code":"NETWORK_ERROR","message":"خطأ","retryable":true}',
    );
    expect(error).toEqual({
      type: 'error',
      code: 'NETWORK_ERROR',
      message: 'خطأ',
      retryable: true,
      keyStatusUpdates: [],
    });
  });

  it('يتجاهل حدثًا غير معروف أو JSON غير صالح أو بيانات ناقصة', () => {
    expect(parseSseBlock('event: mystery\ndata: {"x":1}')).toBeNull();
    expect(parseSseBlock('event: token\ndata: {ليس جسون}')).toBeNull();
    expect(parseSseBlock('event: token\ndata: {"content":"بلا نص"}')).toBeNull();
    expect(parseSseBlock('event: error\ndata: {"code":7}')).toBeNull();
    expect(parseSseBlock('')).toBeNull();
  });

  it('يرفض أكواد حالة مفاتيح غير معروفة', () => {
    const done = parseSseBlock(
      'event: done\ndata: {"keyStatusUpdates":[{"keyId":"k1","status":"مجهول"},{"keyId":"k2","status":"invalid"}]}',
    );
    if (done?.type === 'done') {
      expect(done.keyStatusUpdates).toEqual([{ keyId: 'k2', status: 'invalid' }]);
    }
  });
});

describe('streamTutorChat — التجميع والترتيب', () => {
  it('يجمع الأجزاء بالترتيب حتى حدث الاكتمال', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn(async () =>
        sseResponse([
          { type: 'token', text: 'الجزء الأول ' },
          { type: 'token', text: 'ثم الجزء الثاني' },
          { type: 'done', keyStatusUpdates: [], usage: { outputTokens: 4 } },
        ]),
      ),
    );

    const received: string[] = [];
    const seen: {
      done: { usage?: { outputTokens?: number } } | null;
      error: boolean;
    } = { done: null, error: false };

    await streamTutorChat(PAYLOAD, {
      onToken: (text) => received.push(text),
      onDone: (info) => {
        seen.done = info;
      },
      onError: () => {
        seen.error = true;
      },
    });

    expect(received.join('')).toBe('الجزء الأول ثم الجزء الثاني');
    expect(seen.done?.usage?.outputTokens).toBe(4);
    expect(seen.error).toBe(false);
  });

  it('يحافظ على العربية وUTF-8 حتى مع انقسام الحروف بين الـ chunks', async () => {
    const full = encodeSseEvent({ type: 'token', text: 'مرحبا بالعالم' });
    const bytes = new TextEncoder().encode(full + encodeSseEvent({ type: 'done', keyStatusUpdates: [] }));
    // نقطع البايتات في منتصف حرف عربي متعدد البايتات عمدًا.
    const firstPart = bytes.slice(0, 14);
    const secondPart = bytes.slice(14);

    const stream = new ReadableStream<Uint8Array>({
      start(controller) {
        controller.enqueue(firstPart);
        controller.enqueue(secondPart);
        controller.close();
      },
    });
    vi.stubGlobal(
      'fetch',
      vi.fn(async () =>
        new Response(stream, { headers: { 'Content-Type': 'text/event-stream' } }),
      ),
    );

    const received: string[] = [];
    await streamTutorChat(PAYLOAD, {
      onToken: (text) => received.push(text),
      onDone: () => {},
      onError: () => {},
    });

    expect(received.join('')).toBe('مرحبا بالعالم');
  });

  it('يمرر حدث الخطأ ويستدعي معالج الأخطاء', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn(async () =>
        sseResponse([
          { type: 'token', text: 'بداية' },
          {
            type: 'error',
            code: 'PROVIDER_UNKNOWN',
            message: 'حدث خطأ غير متوقع. حاول مرة أخرى.',
            retryable: false,
            keyStatusUpdates: [],
          },
        ]),
      ),
    );

    const seen: { error: { code: string } | null } = { error: null };
    await streamTutorChat(PAYLOAD, {
      onToken: () => {},
      onDone: () => {},
      onError: (value) => {
        seen.error = value;
      },
    });

    expect(seen.error?.code).toBe('PROVIDER_UNKNOWN');
  });
});

describe('streamTutorChat — ما قبل البث والإلغاء', () => {
  it('يقرأ خطأ JSON الموحد قبل بدء البث', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn(async () =>
        new Response(
          JSON.stringify({
            success: false,
            error: { code: 'NO_API_KEY', message: 'لا يوجد مفتاح.', retryable: false },
          }),
          { status: 403, headers: { 'Content-Type': 'application/json' } },
        ),
      ),
    );

    const seen: { error: { code: string } | null } = { error: null };
    await streamTutorChat(PAYLOAD, {
      onToken: () => {},
      onDone: () => {},
      onError: (value) => {
        seen.error = value;
      },
    });

    expect(seen.error?.code).toBe('NO_API_KEY');
  });

  it('الإلغاء عبر AbortController لا يُعتبر خطأ', async () => {
    const controller = new AbortController();
    vi.stubGlobal(
      'fetch',
      vi.fn(async () => {
        throw new DOMException('The operation was aborted.', 'AbortError');
      }),
    );

    let anyHandlerCalled = false;
    await expect(
      streamTutorChat(
        PAYLOAD,
        {
          onToken: () => {
            anyHandlerCalled = true;
          },
          onDone: () => {
            anyHandlerCalled = true;
          },
          onError: () => {
            anyHandlerCalled = true;
          },
        },
        { signal: controller.signal },
      ),
    ).resolves.toBeUndefined();
    expect(anyHandlerCalled).toBe(false);
  });

  it('فشل الشبكة قبل الاستجابة يرمي TutorClientError', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn(async () => {
        throw new TypeError('fetch failed');
      }),
    );

    await expect(streamTutorChat(PAYLOAD, { onToken: () => {}, onDone: () => {}, onError: () => {} }))
      .rejects.toThrowError(TutorClientError);
  });

  it('يغلق القارئ ويحرره بعد انتهاء البث', async () => {
    const releaseSpy = vi.fn();
    const stream = new ReadableStream<Uint8Array>({
      start(controller) {
        controller.enqueue(new TextEncoder().encode(encodeSseEvent({ type: 'token', text: 'نص' })));
        controller.enqueue(new TextEncoder().encode(encodeSseEvent({ type: 'done', keyStatusUpdates: [] })));
        controller.close();
      },
    });
    const originalGetReader = stream.getReader.bind(stream);
    stream.getReader = (() => {
      const reader = originalGetReader();
      const originalRelease = reader.releaseLock.bind(reader);
      reader.releaseLock = () => {
        releaseSpy();
        originalRelease();
      };
      return reader;
    }) as typeof stream.getReader;

    vi.stubGlobal(
      'fetch',
      vi.fn(async () =>
        new Response(stream, { headers: { 'Content-Type': 'text/event-stream' } }),
      ),
    );

    await streamTutorChat(PAYLOAD, { onToken: () => {}, onDone: () => {}, onError: () => {} });

    expect(releaseSpy).toHaveBeenCalled();
  });
});
