import { afterEach, describe, expect, it, vi } from 'vitest';
import { ProviderError } from '@/lib/ai-providers/errors';
import { getActiveModel } from '@/lib/ai-providers/provider-selector';
import type { UserApiKey } from '@/types/providers';

function makeKey(overrides: Partial<UserApiKey> = {}): UserApiKey {
  return {
    id: 'key-1',
    provider: 'gemini',
    label: 'مفتاح اختبار',
    apiKey: 'test-key-123456',
    status: 'active',
    isDefault: false,
    createdAt: '2026-01-01T00:00:00.000Z',
    ...overrides,
  };
}

function expectProviderError(fn: () => unknown, code: ProviderError['code']): ProviderError {
  try {
    fn();
  } catch (error) {
    expect(error).toBeInstanceOf(ProviderError);
    const providerError = error as ProviderError;
    expect(providerError.code).toBe(code);
    return providerError;
  }
  throw new Error(`Expected ProviderError(${code}) but nothing was thrown`);
}

describe('getActiveModel — قواعد الاختيار', () => {
  afterEach(() => {
    vi.unstubAllEnvs();
  });

  it('يرمي NO_API_KEY عند عدم وجود أي مفتاح', () => {
    vi.stubEnv('DEV_TESTING_MODE', 'false');
    vi.stubEnv('GEMINI_API_KEY', 'env-key-should-not-be-used');

    expectProviderError(() => getActiveModel({ keys: [] }), 'NO_API_KEY');
  });

  it('يتجاهل المفاتيح بحالة invalid', () => {
    const result = getActiveModel({
      keys: [
        makeKey({ id: 'bad', status: 'invalid', isDefault: true }),
        makeKey({ id: 'good', createdAt: '2026-01-02T00:00:00.000Z' }),
      ],
    });

    expect(result.key.id).toBe('good');
  });

  it('يتجاهل المفاتيح بحالة exhausted', () => {
    const result = getActiveModel({
      keys: [
        makeKey({ id: 'tired', status: 'exhausted', isDefault: true }),
        makeKey({ id: 'fresh', createdAt: '2026-01-02T00:00:00.000Z' }),
      ],
    });

    expect(result.key.id).toBe('fresh');
  });

  it('يختار المفتاح الافتراضي النشط أولًا', () => {
    const result = getActiveModel({
      keys: [
        makeKey({ id: 'first', createdAt: '2026-01-01T00:00:00.000Z' }),
        makeKey({
          id: 'default-one',
          isDefault: true,
          createdAt: '2026-01-03T00:00:00.000Z',
        }),
        makeKey({ id: 'other', createdAt: '2026-01-02T00:00:00.000Z' }),
      ],
    });

    expect(result.key.id).toBe('default-one');
    expect(result.provider.name).toBe('gemini');
    expect(result.provider.enabled).toBe(true);
  });

  it('يختار أول مفتاح نشط عند عدم وجود مفتاح افتراضي', () => {
    const result = getActiveModel({
      keys: [
        makeKey({ id: 'a', createdAt: '2026-01-01T00:00:00.000Z' }),
        makeKey({ id: 'b', createdAt: '2026-01-02T00:00:00.000Z' }),
      ],
    });

    expect(result.key.id).toBe('a');
  });

  it('عند تحديد مزود، يبحث داخله فقط', () => {
    const result = getActiveModel({
      keys: [
        makeKey({ id: 'gem', provider: 'gemini', isDefault: true }),
        makeKey({ id: 'sim', provider: 'mock', createdAt: '2026-01-02T00:00:00.000Z' }),
      ],
      preferredProvider: 'mock',
    });

    expect(result.key.id).toBe('sim');
    expect(result.provider.name).toBe('mock');
  });

  it('يرمي ALL_KEYS_EXHAUSTED عندما تكون كل المفاتيح غير صالحة أو مستنفدة', () => {
    expectProviderError(
      () =>
        getActiveModel({
          keys: [
            makeKey({ id: 'a', status: 'exhausted' }),
            makeKey({ id: 'b', status: 'invalid', createdAt: '2026-01-02T00:00:00.000Z' }),
          ],
        }),
      'ALL_KEYS_EXHAUSTED',
    );
  });

  it('يرمي ALL_KEYS_EXHAUSTED أيضًا عندما تكون مفاتيح المزود المفضل فقط مستنفدة', () => {
    expectProviderError(
      () =>
        getActiveModel({
          keys: [
            makeKey({ id: 'gem', provider: 'gemini', status: 'exhausted' }),
            makeKey({ id: 'sim', provider: 'mock', createdAt: '2026-01-02T00:00:00.000Z' }),
          ],
          preferredProvider: 'gemini',
        }),
      'ALL_KEYS_EXHAUSTED',
    );
  });

  it('لا يختار تلقائيًا مفتاحًا لمزود غير مفعّل (عنصر نائب)', () => {
    expectProviderError(
      () =>
        getActiveModel({
          keys: [makeKey({ id: 'or', provider: 'openrouter' })],
        }),
      'PROVIDER_NOT_CONFIGURED',
    );
  });

  it('لا يستخدم متغير البيئة عندما يكون DEV_TESTING_MODE=false حتى مع الخيار الصريح', () => {
    vi.stubEnv('DEV_TESTING_MODE', 'false');
    vi.stubEnv('GEMINI_API_KEY', 'env-key-should-not-be-used');

    expectProviderError(
      () => getActiveModel({ keys: [], allowDevEnvironmentFallback: true }),
      'NO_API_KEY',
    );
  });

  it('لا يستخدم متغير البيئة دون الخيار الصريح حتى في وضع الاختبار', () => {
    vi.stubEnv('DEV_TESTING_MODE', 'true');
    vi.stubEnv('GEMINI_API_KEY', 'env-dev-key-123456');

    expectProviderError(() => getActiveModel({ keys: [] }), 'NO_API_KEY');
  });

  it('يستخدم fallback التطوير فقط عند اجتماع الوضع والخيار الصريح', () => {
    vi.stubEnv('DEV_TESTING_MODE', 'true');
    vi.stubEnv('GEMINI_API_KEY', 'env-dev-key-123456');

    const result = getActiveModel({ keys: [], allowDevEnvironmentFallback: true });

    expect(result.key.apiKey).toBe('env-dev-key-123456');
    expect(result.provider.name).toBe('gemini');
  });

  it('لا يستخدم fallback التطوير إذا وُجدت مفاتيح مستخدم (حتى لو كانت مستنفدة)', () => {
    vi.stubEnv('DEV_TESTING_MODE', 'true');
    vi.stubEnv('GEMINI_API_KEY', 'env-dev-key-123456');

    expectProviderError(
      () =>
        getActiveModel({
          keys: [makeKey({ id: 'a', status: 'exhausted' })],
          allowDevEnvironmentFallback: true,
        }),
      'ALL_KEYS_EXHAUSTED',
    );
  });

  it('لا يغيّر حالة أي مفتاح أثناء الاختيار', () => {
    const keys = [makeKey({ id: 'a', status: 'active' }), makeKey({ id: 'b', status: 'active' })];

    getActiveModel({ keys });

    expect(keys[0]?.status).toBe('active');
    expect(keys[1]?.status).toBe('active');
  });
});
