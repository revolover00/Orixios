import { describe, expect, it, vi } from 'vitest';
import { runWithKeyRotation } from '@/lib/ai-providers/provider-selector';
import { ProviderError } from '@/lib/ai-providers/errors';
import type { ApiKeyStatus, UserApiKey } from '@/types/providers';

function makeKey(overrides: Partial<UserApiKey> = {}): UserApiKey {
  return {
    id: 'key-1',
    provider: 'gemini',
    label: 'مفتاح اختبار',
    apiKey: 'test-key-123456',
    status: 'active',
    isDefault: false,
    createdAt: '2026-01-01T00:00:00.000Z',
    ...overrides,
  };
}

describe('runWithKeyRotation — دورة الأخطاء والانتقال بين المفاتيح', () => {
  it('ينتقل إلى مفتاح آخر بعد QUOTA_EXCEEDED ويعلّم الأول مستنفدًا', async () => {
    const keys = [
      makeKey({ id: 'k1', createdAt: '2026-01-01T00:00:00.000Z' }),
      makeKey({ id: 'k2', createdAt: '2026-01-02T00:00:00.000Z' }),
    ];
    const invoke = vi.fn(async (key: UserApiKey) => {
      if (key.id === 'k1') {
        throw { statusCode: 429, message: 'quota exceeded' };
      }
      return 'رد ناجح';
    });

    const outcome = await runWithKeyRotation({ keys, invoke });

    expect(outcome.ok).toBe(true);
    if (outcome.ok) {
      expect(outcome.text).toBe('رد ناجح');
      expect(outcome.usedKeyId).toBe('k2');
      expect(outcome.provider).toBe('gemini');
    }
    expect(outcome.keyStatusUpdates).toContainEqual({ keyId: 'k1', status: 'exhausted' });
    expect(invoke).toHaveBeenCalledTimes(2);
  });

  it('يرجِع ALL_KEYS_EXHAUSTED بعد استنفاد كل المفاتيح ويعلّمها جميعًا', async () => {
    const keys = [
      makeKey({ id: 'k1', createdAt: '2026-01-01T00:00:00.000Z' }),
      makeKey({ id: 'k2', createdAt: '2026-01-02T00:00:00.000Z' }),
      makeKey({ id: 'k3', createdAt: '2026-01-03T00:00:00.000Z' }),
    ];
    const invoke = vi.fn(async () => {
      throw { statusCode: 429, message: 'rate limit exceeded' };
    });

    const outcome = await runWithKeyRotation({ keys, invoke });

    expect(outcome.ok).toBe(false);
    if (!outcome.ok) {
      expect(outcome.error.code).toBe('ALL_KEYS_EXHAUSTED');
    }
    expect(outcome.keyStatusUpdates).toEqual([
      { keyId: 'k1', status: 'exhausted' },
      { keyId: 'k2', status: 'exhausted' },
      { keyId: 'k3', status: 'exhausted' },
    ]);
    // تجربة واحدة فقط لكل مفتاح — لا حلقات مفتوحة.
    expect(invoke).toHaveBeenCalledTimes(3);
  });

  it('يتوقف فورًا بعد INVALID_API_KEY دون الانتقال إلى مفتاح آخر', async () => {
    const keys = [
      makeKey({ id: 'k1', createdAt: '2026-01-01T00:00:00.000Z' }),
      makeKey({ id: 'k2', createdAt: '2026-01-02T00:00:00.000Z' }),
    ];
    const invoke = vi.fn(async () => {
      throw { statusCode: 401, message: 'Unauthorized' };
    });

    const outcome = await runWithKeyRotation({ keys, invoke });

    expect(outcome.ok).toBe(false);
    if (!outcome.ok) {
      expect(outcome.error.code).toBe('INVALID_API_KEY');
      expect(outcome.error.retryable).toBe(false);
      expect(outcome.error.keyId).toBe('k1');
    }
    expect(outcome.keyStatusUpdates).toContainEqual({ keyId: 'k1', status: 'invalid' });
    expect(outcome.keyStatusUpdates).not.toContainEqual(
      expect.objectContaining({ keyId: 'k2' }),
    );
    expect(invoke).toHaveBeenCalledTimes(1);
  });

  it('لا يغيّر حالة المفتاح عند NETWORK_ERROR ويرجِع خطأ مؤقتًا قابلًا لإعادة المحاولة', async () => {
    const onKeyStatusChange = vi.fn();
    const keys = [makeKey({ id: 'k1' })];
    const invoke = vi.fn(async () => {
      throw new TypeError('fetch failed');
    });

    const outcome = await runWithKeyRotation({ keys, invoke, onKeyStatusChange });

    expect(outcome.ok).toBe(false);
    if (!outcome.ok) {
      expect(outcome.error.code).toBe('NETWORK_ERROR');
      expect(outcome.error.retryable).toBe(true);
    }
    expect(outcome.keyStatusUpdates).toEqual([]);
    expect(onKeyStatusChange).not.toHaveBeenCalled();
    expect(invoke).toHaveBeenCalledTimes(1);
  });

  it('يحترم الحد الأعلى لعدد المحاولات (لا تجاوز غير محدود)', async () => {
    const keys = Array.from({ length: 10 }, (_, index) =>
      makeKey({ id: `k${index}`, createdAt: `2026-01-${String(index + 1).padStart(2, '0')}T00:00:00.000Z` }),
    );
    const invoke = vi.fn(async () => {
      throw { statusCode: 429, message: 'quota' };
    });

    const outcome = await runWithKeyRotation({ keys, invoke, maxAttempts: 20 });

    expect(outcome.ok).toBe(false);
    // الحد الأعلى الداخلي يمنع تجاوز عدد المفاتيح المجرَّبة.
    expect(invoke).toHaveBeenCalledTimes(5);
  });

  it('يستدعي خطاف تغيير الحالة عند تعليم مفتاح', async () => {
    const onKeyStatusChange = vi.fn();
    const keys = [
      makeKey({ id: 'k1', createdAt: '2026-01-01T00:00:00.000Z' }),
      makeKey({ id: 'k2', createdAt: '2026-01-02T00:00:00.000Z' }),
    ];
    const statuses: Array<{ id: string; status: ApiKeyStatus }> = [];
    const invoke = vi.fn(async (key: UserApiKey) => {
      if (key.id === 'k1') {
        throw { statusCode: 429, message: 'quota' };
      }
      return 'تمام';
    });

    await runWithKeyRotation({
      keys,
      invoke,
      onKeyStatusChange: (keyId, status) => {
        statuses.push({ id: keyId, status });
        onKeyStatusChange();
      },
    });

    expect(statuses).toEqual([{ id: 'k1', status: 'exhausted' }]);
  });

  it('يرمي NO_API_KEY فورًا عندما لا توجد مفاتيح أصلًا', async () => {
    const invoke = vi.fn();

    const outcome = await runWithKeyRotation({ keys: [], invoke });

    expect(outcome.ok).toBe(false);
    if (!outcome.ok) {
      expect(outcome.error.code).toBe('NO_API_KEY');
    }
    expect(invoke).not.toHaveBeenCalled();
  });

  it('لا يكشف قيمة المفتاح في رسالة الخطأ المعادة', async () => {
    const secretKey = makeKey({ id: 'k1', apiKey: 'ultra-secret-value-999' });
    const invoke = vi.fn(async (key: UserApiKey) => {
      // الخطأ الخام يحمل قيمة المفتاح عمدًا لمحاكاة تسريب محتمل.
      throw new Error(`upstream failure for ${key.apiKey}`);
    });

    const outcome = await runWithKeyRotation({ keys: [secretKey], invoke });

    expect(outcome.ok).toBe(false);
    if (!outcome.ok) {
      expect(outcome.error.message).not.toContain('ultra-secret-value-999');
      expect(outcome.error.message.length).toBeGreaterThan(0);
    }
  });

  it('يعيد تمرير ProviderError كما هو دون إعادة تصنيف', async () => {
    const keys = [makeKey({ id: 'k1' })];
    const invoke = vi.fn(async () => {
      throw new ProviderError('INVALID_API_KEY', { provider: 'gemini' });
    });

    const outcome = await runWithKeyRotation({ keys, invoke });

    expect(outcome.ok).toBe(false);
    if (!outcome.ok) {
      expect(outcome.error.code).toBe('INVALID_API_KEY');
      expect(outcome.error.provider).toBe('gemini');
      expect(outcome.error.keyId).toBe('k1');
    }
  });
});
