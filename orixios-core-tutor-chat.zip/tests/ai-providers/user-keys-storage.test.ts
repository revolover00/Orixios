import { beforeEach, describe, expect, it } from 'vitest';
import {
  addApiKey,
  applyKeyStatusUpdates,
  deleteApiKey,
  evaluateKeyAccess,
  getActiveApiKeys,
  getDefaultApiKey,
  hasDuplicateApiKey,
  listApiKeys,
  listUsableApiKeys,
  maskApiKey,
  renameApiKey,
  sanitizeStoredKeys,
  setDefaultApiKey,
  toPublicApiKey,
  updateApiKeyStatus,
} from '@/lib/ai-providers/user-keys-storage';

const RAW_STORAGE_KEY = 'orixios.tutor.userApiKeys.v1';

class MemoryStorage {
  private store = new Map<string, string>();

  get length(): number {
    return this.store.size;
  }

  clear(): void {
    this.store.clear();
  }

  getItem(key: string): string | null {
    return this.store.has(key) ? (this.store.get(key) ?? null) : null;
  }

  key(index: number): string | null {
    return [...this.store.keys()][index] ?? null;
  }

  removeItem(key: string): void {
    this.store.delete(key);
  }

  setItem(key: string, value: string): void {
    this.store.set(key, value);
  }
}

type MutableGlobals = {
  window?: unknown;
  localStorage?: unknown;
};

function installBrowserGlobals(): void {
  const globals = globalThis as unknown as MutableGlobals;
  globals.localStorage = new MemoryStorage();
  globals.window = globalThis;
}

function removeWindow(): void {
  const globals = globalThis as unknown as Record<string, unknown>;
  delete globals.window;
}

beforeEach(() => {
  installBrowserGlobals();
});

describe('العمليات الأساسية', () => {
  it('يجعل أول مفتاح مضاف هو الافتراضي', () => {
    const first = addApiKey({ provider: 'gemini', label: 'الأول', apiKey: 'key-aaaaaaaa' });
    const second = addApiKey({ provider: 'gemini', label: 'الثاني', apiKey: 'key-bbbbbbbb' });

    expect(first.isDefault).toBe(true);
    expect(second.isDefault).toBe(false);
  });

  it('يحسب حالة الوصول: لا مفاتيح / الكل مستنفد / جاهز', () => {
    expect(evaluateKeyAccess()).toBe('NO_API_KEY');

    const key = addApiKey({ provider: 'gemini', label: 'مفتاح', apiKey: 'key-aaaaaaaa' });
    expect(evaluateKeyAccess()).toBe('READY');

    applyKeyStatusUpdates([{ keyId: key.id, status: 'exhausted' }]);
    expect(evaluateKeyAccess()).toBe('ALL_KEYS_EXHAUSTED');

    addApiKey({ provider: 'mock', label: 'محاكاة', apiKey: 'mock-key-123' });
    expect(evaluateKeyAccess()).toBe('READY');
  });

  it('يرتب المفاتيح الصالحة: الافتراضي أولًا', () => {
    const first = addApiKey({ provider: 'gemini', label: 'الأول', apiKey: 'key-aaaaaaaa' });
    const second = addApiKey({ provider: 'gemini', label: 'الثاني', apiKey: 'key-bbbbbbbb' });

    setDefaultApiKey(second.id);

    const usable = listUsableApiKeys();
    expect(usable[0]?.id).toBe(second.id);
    expect(usable[1]?.id).toBe(first.id);
  });

  it('يطبق تحديثات الحالة القادمة من الخادم', () => {
    const key = addApiKey({ provider: 'gemini', label: 'مفتاح', apiKey: 'key-aaaaaaaa' });

    applyKeyStatusUpdates([{ keyId: key.id, status: 'invalid' }]);

    expect(listApiKeys()[0]?.status).toBe('invalid');
  });

  it('يحذف المفتاح', () => {
    const key = addApiKey({ provider: 'gemini', label: 'مفتاح', apiKey: 'key-aaaaaaaa' });

    deleteApiKey(key.id);

    expect(listApiKeys()).toHaveLength(0);
  });

  it('يحدّث حالة المفتاح مباشرة', () => {
    const key = addApiKey({ provider: 'gemini', label: 'مفتاح', apiKey: 'key-aaaaaaaa' });

    updateApiKeyStatus(key.id, 'exhausted');

    expect(getActiveApiKeys()).toHaveLength(0);
  });

  it('يعيد المفاتيح النشطة فقط عبر getActiveApiKeys', () => {
    addApiKey({ provider: 'gemini', label: 'نشط', apiKey: 'key-aaaaaaaa' });
    const second = addApiKey({ provider: 'gemini', label: 'سيء', apiKey: 'key-bbbbbbbb' });
    updateApiKeyStatus(second.id, 'invalid');

    const active = getActiveApiKeys();

    expect(active).toHaveLength(1);
    expect(active[0]?.label).toBe('نشط');
  });

  it('يعيد المفتاح الافتراضي عبر getDefaultApiKey', () => {
    addApiKey({ provider: 'gemini', label: 'الأول', apiKey: 'key-aaaaaaaa' });
    const second = addApiKey({ provider: 'gemini', label: 'الثاني', apiKey: 'key-bbbbbbbb' });

    setDefaultApiKey(second.id);

    expect(getDefaultApiKey()?.id).toBe(second.id);
  });
});

describe('الحمايات', () => {
  it('يتعامل بأمان عندما لا يتوفر localStorage (سياق خادم)', () => {
    removeWindow();

    expect(listApiKeys()).toEqual([]);
    expect(evaluateKeyAccess()).toBe('NO_API_KEY');
    expect(() =>
      addApiKey({ provider: 'gemini', label: 'خادم', apiKey: 'key-aaaaaaaa' }),
    ).not.toThrow();
    expect(listApiKeys()).toEqual([]);

    installBrowserGlobals();
  });

  it('يتجاهل JSON تالفًا داخل التخزين', () => {
    window.localStorage.setItem(RAW_STORAGE_KEY, '{oops: this is not json,,');

    expect(listApiKeys()).toEqual([]);

    // الإضافة بعد التلف تعمل بشكل طبيعي.
    addApiKey({ provider: 'gemini', label: 'جديد', apiKey: 'key-aaaaaaaa' });
    expect(listApiKeys()).toHaveLength(1);
  });

  it('يستبعد البيانات القديمة التي لا تطابق النوع الحالي', () => {
    window.localStorage.setItem(
      RAW_STORAGE_KEY,
      JSON.stringify([
        { label: 'بدون provider وبدون id', apiKey: 'abcdef123456' },
        { id: 'no-key', provider: 'gemini', label: 'بدون قيمة مفتاح' },
        { id: 'bad-provider', provider: 'not-a-provider', apiKey: 'abcdef123456' },
        'نص غريب داخل المصفوفة',
        {
          id: 'سليم',
          provider: 'gemini',
          label: 'مفتاح سليم',
          apiKey: 'valid-key-123',
          status: 'حالة-مجهولة',
        },
      ]),
    );

    const keys = listApiKeys();

    expect(keys).toHaveLength(1);
    expect(keys[0]?.id).toBe('سليم');
    // الحالة المجهولة تُصحَّح إلى القيمة الافتراضية الآمنة.
    expect(keys[0]?.status).toBe('active');
  });

  it('يمنع وجود أكثر من مفتاح افتراضي واحد', () => {
    window.localStorage.setItem(
      RAW_STORAGE_KEY,
      JSON.stringify([
        {
          id: 'a',
          provider: 'gemini',
          label: 'أ',
          apiKey: 'key-aaaaaaaa',
          status: 'active',
          isDefault: true,
          createdAt: '2026-01-01T00:00:00.000Z',
        },
        {
          id: 'b',
          provider: 'gemini',
          label: 'ب',
          apiKey: 'key-bbbbbbbb',
          status: 'active',
          isDefault: true,
          createdAt: '2026-01-02T00:00:00.000Z',
        },
      ]),
    );

    const defaults = listApiKeys().filter((key) => key.isDefault);

    expect(defaults).toHaveLength(1);
    expect(defaults[0]?.id).toBe('a');

    // setDefaultApiKey يصفّر البقية أيضًا.
    setDefaultApiKey('b');
    expect(listApiKeys().filter((key) => key.isDefault).map((key) => key.id)).toEqual(['b']);
  });

  it('يعقّم المصفوفات غير الصالحة عبر sanitizeStoredKeys', () => {
    expect(sanitizeStoredKeys(null)).toEqual([]);
    expect(sanitizeStoredKeys('نص')).toEqual([]);
    expect(sanitizeStoredKeys({ id: 'كائن' })).toEqual([]);
  });

  it('لا يكشف القيمة الخام للمفتاح في النسخة العامة', () => {
    const key = addApiKey({
      provider: 'gemini',
      label: 'مفتاح',
      apiKey: 'super-secret-value-99',
    });

    const publicView = toPublicApiKey(key);

    expect(JSON.stringify(publicView)).not.toContain('super-secret-value-99');
    expect(publicView.keyPreview).toBe('supe••••••••••e-99');
  });
});

describe('maskApiKey', () => {
  it('يخفي المفتاح بصيغة أول 4 محارف وآخر 4', () => {
    expect(maskApiKey('AIzaSyA1234567890abcd1234')).toBe('AIza••••••••••1234');
  });

  it('يقنّع المفاتيح القصيرة بالكامل', () => {
    expect(maskApiKey('ab12')).toBe('••••••••••');
    expect(maskApiKey('12345678')).toBe('••••••••••');
  });

  it('يقص المسافات قبل الإخفاء', () => {
    expect(maskApiKey('  AIzaSyA1234567890abcd1234  ')).toBe('AIza••••••••••1234');
  });
});

describe('إعادة التسمية وكشف التكرار', () => {
  it('يعيد تسمية مفتاح موجود ويرفض الفارغ والمجهول', () => {
    const key = addApiKey({ provider: 'gemini', label: 'اسم قديم', apiKey: 'key-rename-1' });

    expect(renameApiKey(key.id, '  اسم جديد  ')).toBe(true);
    expect(listApiKeys()[0]?.label).toBe('اسم جديد');
    expect(renameApiKey(key.id, '    ')).toBe(false);
    expect(renameApiKey('no-such-id', 'اسم')).toBe(false);
  });

  it('يكشف تكرار نفس القيمة لنفس المزود فقط', () => {
    addApiKey({ provider: 'gemini', label: 'أصلي', apiKey: 'dup-key-12345' });

    expect(hasDuplicateApiKey('gemini', '  dup-key-12345  ')).toBe(true);
    expect(hasDuplicateApiKey('mock', 'dup-key-12345')).toBe(false);
    expect(hasDuplicateApiKey('gemini', 'other-key-999')).toBe(false);
    expect(hasDuplicateApiKey('gemini', '   ')).toBe(false);
  });
});

describe('الحذف وترقية الافتراضي', () => {
  it('يرقّي أقدم مفتاح نشط عند حذف المفتاح الافتراضي', () => {
    const first = addApiKey({ provider: 'gemini', label: 'الأول', apiKey: 'key-del-aaa' });
    const second = addApiKey({ provider: 'gemini', label: 'الثاني', apiKey: 'key-del-bbb' });
    const third = addApiKey({ provider: 'gemini', label: 'الثالث', apiKey: 'key-del-ccc' });
    updateApiKeyStatus(second.id, 'invalid');

    deleteApiKey(first.id);

    const remaining = listApiKeys();
    expect(remaining).toHaveLength(2);
    // الثالث أقدم مفتاح نشط متبقٍ فيصبح الافتراضي.
    expect(remaining.find((key) => key.id === third.id)?.isDefault).toBe(true);
    expect(remaining.find((key) => key.id === second.id)?.isDefault).toBe(false);
  });

  it('يرقّي أي مفتاح متبقٍ حتى لو لم يكن نشطًا عند عدم وجود نشط', () => {
    const first = addApiKey({ provider: 'gemini', label: 'الأول', apiKey: 'key-del-ddd' });
    const second = addApiKey({ provider: 'gemini', label: 'الثاني', apiKey: 'key-del-eee' });
    updateApiKeyStatus(second.id, 'exhausted');

    deleteApiKey(first.id);

    const remaining = listApiKeys();
    expect(remaining).toHaveLength(1);
    expect(remaining[0]?.isDefault).toBe(true);
  });

  it('حذف آخر مفتاح يترك قائمة فارغة دون كسر', () => {
    const key = addApiKey({ provider: 'gemini', label: 'الأخير', apiKey: 'key-last-one' });

    deleteApiKey(key.id);

    expect(listApiKeys()).toEqual([]);
    expect(evaluateKeyAccess()).toBe('NO_API_KEY');
  });

  it('حذف معرّف غير موجود لا يفعل شيئًا', () => {
    addApiKey({ provider: 'gemini', label: 'باقٍ', apiKey: 'key-stay-one' });

    deleteApiKey('ghost-id');

    expect(listApiKeys()).toHaveLength(1);
  });
});

describe('أعطال التخزين', () => {
  it('فشل القراءة يعيد آخر لقطة صالحة دون كسر التطبيق', () => {
    // استقرار الذاكرة المؤقتة أولًا على التخزين الفارغ السليم.
    listApiKeys();

    const brokenStorage = {
      getItem: () => {
        throw new Error('read denied');
      },
      setItem: () => {
        throw new Error('write denied');
      },
      removeItem: () => {},
      clear: () => {},
      key: () => null,
      length: 0,
    };
    const globals = globalThis as unknown as MutableGlobals;
    globals.localStorage = brokenStorage;
    globals.window = globalThis;

    // القراءة الأخيرة الصالحة كانت قائمة فارغة.
    expect(listApiKeys()).toEqual([]);
    expect(() =>
      addApiKey({ provider: 'gemini', label: 'محاولة', apiKey: 'key-broken-1' }),
    ).not.toThrow();
    // بعد إضافة في وضع الذاكرة فقط: تبقى النية الأخيرة دون انهيار،
    // ولا تُكشف أي قيمة مفتاح في أي مسار عطل.
    expect(listApiKeys()).toHaveLength(1);
    expect(evaluateKeyAccess()).toBe('READY');

    installBrowserGlobals();
    // كتابات ناجحة تعيد الخروج من وضع الذاكرة فقط وتفرغ الحالة.
    for (const key of listApiKeys()) {
      deleteApiKey(key.id);
    }
    expect(listApiKeys()).toEqual([]);
  });

  it('فشل الكتابة لا يكسر الواجهة ويبقي الحالة في الذاكرة المؤقتة', () => {
    listApiKeys();

    let writeFailed = false;
    const writeOnlyBroken = {
      getItem: () => JSON.stringify([]),
      setItem: () => {
        writeFailed = true;
        throw new Error('storage quota exceeded');
      },
      removeItem: () => {},
      clear: () => {},
      key: () => null,
      length: 0,
    };
    const globals = globalThis as unknown as MutableGlobals;
    globals.localStorage = writeOnlyBroken;
    globals.window = globalThis;

    expect(() =>
      addApiKey({ provider: 'gemini', label: 'ذاكرة فقط', apiKey: 'key-memory-only' }),
    ).not.toThrow();
    expect(writeFailed).toBe(true);
    // الحالة بقيت في الذاكرة المؤقتة دون تسريب قيمة المفتاح في أي خطأ.
    expect(listApiKeys()).toHaveLength(1);

    installBrowserGlobals();
    // تصفير وضع الذاكرة فقط بكتابات ناجحة قبل بقية الاختبارات.
    for (const key of listApiKeys()) {
      deleteApiKey(key.id);
    }
  });
});
