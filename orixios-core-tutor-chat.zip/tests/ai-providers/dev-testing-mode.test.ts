import { afterEach, describe, expect, it, vi } from 'vitest';
import {
  getDevTestingFallbackKey,
  isDevTestingMode,
} from '@/lib/ai-providers/provider-config';
import { ProviderError } from '@/lib/ai-providers/errors';
import { getActiveModel } from '@/lib/ai-providers/provider-selector';

describe('وضع الاختبار التطويري وحماية fallback', () => {
  afterEach(() => {
    vi.unstubAllEnvs();
  });

  it('لا يستخدم GEMINI_API_KEY تلقائيًا عندما يكون DEV_TESTING_MODE=false', () => {
    vi.stubEnv('DEV_TESTING_MODE', 'false');
    vi.stubEnv('GEMINI_API_KEY', 'env-key-123456');

    expect(isDevTestingMode()).toBe(false);
    expect(getDevTestingFallbackKey()).toBeNull();
    expect(() =>
      getActiveModel({ keys: [], allowDevEnvironmentFallback: true }),
    ).toThrowError(ProviderError);
  });

  it('لا يوجد أي استخدام تلقائي لمتغير البيئة في الوضع الافتراضي', () => {
    // .env الافتراضي يحمل DEV_TESTING_MODE=false؛ حتى لو وُجد مفتاح بيئي
    // فلا يجوز أن يظهر أي اختيار معتمد عليه دون الخيار الصريح.
    vi.stubEnv('GEMINI_API_KEY', 'env-key-123456');

    const error = (() => {
      try {
        getActiveModel({ keys: [] });
        return null;
      } catch (caught) {
        return caught;
      }
    })();

    expect(error).toBeInstanceOf(ProviderError);
    expect((error as ProviderError).code).toBe('NO_API_KEY');
  });

  it('يقرأ مفتاح التطوير فقط عندما يكون الوضع مفعّلًا', () => {
    vi.stubEnv('DEV_TESTING_MODE', 'true');
    vi.stubEnv('GEMINI_API_KEY', 'env-dev-key-123456');

    const key = getDevTestingFallbackKey();

    expect(key).not.toBeNull();
    expect(key?.provider).toBe('gemini');
    expect(key?.apiKey).toBe('env-dev-key-123456');
    expect(key?.status).toBe('active');
  });

  it('يتجاهل مفتاح البيئة الفارغ حتى في وضع الاختبار', () => {
    vi.stubEnv('DEV_TESTING_MODE', 'true');
    vi.stubEnv('GEMINI_API_KEY', '   ');

    expect(getDevTestingFallbackKey()).toBeNull();
  });

  it('يستخدم الـ fallback عبر الخيار الصريح فقط (وليس تلقائيًا)', () => {
    vi.stubEnv('DEV_TESTING_MODE', 'true');
    vi.stubEnv('GEMINI_API_KEY', 'env-dev-key-123456');

    // بدون الخيار الصريح: لا مفتاح.
    const withoutOption = (() => {
      try {
        getActiveModel({ keys: [] });
        return null;
      } catch (caught) {
        return caught;
      }
    })();
    expect((withoutOption as ProviderError).code).toBe('NO_API_KEY');

    // مع الخيار الصريح: يُستخدم مفتاح التطوير.
    const withOption = getActiveModel({ keys: [], allowDevEnvironmentFallback: true });
    expect(withOption.key.apiKey).toBe('env-dev-key-123456');
  });

  it('لا يكشف قيمة المفتاح في رسائل الأخطاء', () => {
    vi.stubEnv('DEV_TESTING_MODE', 'false');
    vi.stubEnv('GEMINI_API_KEY', 'super-secret-env-value');

    try {
      getActiveModel({ keys: [], allowDevEnvironmentFallback: true });
      expect.unreachable('كان يجب أن يرمي الخطأ');
    } catch (error) {
      const providerError = error as ProviderError;
      expect(providerError.message).not.toContain('super-secret-env-value');
      expect(JSON.stringify({ message: providerError.message, code: providerError.code }))
        .not.toContain('super-secret-env-value');
    }
  });
});
