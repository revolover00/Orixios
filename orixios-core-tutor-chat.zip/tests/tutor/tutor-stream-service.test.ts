/**
 * اختبارات مسار البث في خدمة الشات باستخدام عملاء مزيفين محقونين.
 * لا يُستدعى أي API خارجي.
 */

import { describe, expect, it, vi } from 'vitest';
import type { ProviderClient } from '@/lib/ai-providers/provider-client';
import type {
  ProviderGenerateRequest,
  ProviderStreamRequest,
} from '@/lib/ai-providers/provider-request';
import type {
  ProviderGenerateResponse,
  ProviderStreamChunk,
} from '@/lib/ai-providers/provider-response';
import { sessionStore } from '@/lib/sessions/session-store';
import {
  processTutorRequest,
  startTutorStream,
  type TutorServiceDeps,
  type TutorServiceInput,
} from '@/lib/tutor/tutor-service';
import type { TutorStreamEvent } from '@/lib/tutor/tutor-stream';
import type { ProviderName, UserKeyCredential } from '@/types/providers';

function createSession(subjectId: 'mathematics' | 'physics' = 'mathematics'): string {
  return sessionStore.createSession({ studentId: 'stream-test-student', subjectId }).id;
}

function makeInput(overrides: Partial<TutorServiceInput> = {}): TutorServiceInput {
  return {
    sessionId: createSession(),
    subjectId: 'mathematics',
    messages: [{ role: 'user', content: 'اشرح المعادلات الخطية' }],
    keys: [{ id: 'k1', provider: 'mock', apiKey: 'stream-test-key-1' }],
    ...overrides,
  };
}

async function collect(events: AsyncIterable<TutorStreamEvent>): Promise<TutorStreamEvent[]> {
  const collected: TutorStreamEvent[] = [];
  for await (const event of events) {
    collected.push(event);
  }
  return collected;
}

interface FakeClientOptions {
  chunks?: ProviderStreamChunk[];
  streamError?: unknown;
  streamErrorAfter?: number;
  noStreamSupport?: boolean;
}

function fakeClientFactory(
  options: FakeClientOptions,
): { deps: TutorServiceDeps; generateCalls: ReturnType<typeof vi.fn> } {
  const generateCalls = vi.fn();
  const streamCalls = vi.fn();

  const createClient = (_provider: ProviderName): ProviderClient => {
    const client: ProviderClient = {
      providerName: _provider,
      generateResponse: async (_input: ProviderGenerateRequest): Promise<ProviderGenerateResponse> => {
        generateCalls();
        return { text: 'رد كامل احتياطي' };
      },
    };
    if (!options.noStreamSupport) {
      client.streamResponse = async (_input: ProviderStreamRequest) => {
        streamCalls();
        const chunks = options.chunks ?? [];
        const failAfter = options.streamErrorAfter ?? Number.MAX_SAFE_INTEGER;
        async function* parts(): AsyncGenerator<ProviderStreamChunk> {
          let yielded = 0;
          for (const chunk of chunks) {
            if (options.streamError && yielded >= failAfter) {
              throw options.streamError;
            }
            yield chunk;
            yielded += 1;
          }
          // الخطأ بعد كل الأجزاء المسموحة.
          if (options.streamError && yielded >= failAfter) {
            throw options.streamError;
          }
        }
        return parts();
      };
    }
    return client;
  };

  return { deps: { createClient, sessionStore }, generateCalls };
}

/** عميل يرمي خطأ قبل إنتاج أي جزء (فشل تأسيس البث). */
function failingStreamClient(error: unknown): TutorServiceDeps {
  return {
    createClient: (provider: ProviderName): ProviderClient => ({
      providerName: provider,
      generateResponse: async () => ({ text: 'لا يجب أن يصل' }),
      streamResponse: async () => {
        throw error;
      },
    }),
    sessionStore,
  };
}

describe('التحقق قبل بدء البث', () => {
  it('جلسة غير موجودة: فشل موحد قبل البث دون استدعاء مزود', async () => {
    const factory = fakeClientFactory({ chunks: [{ text: 'س' }] });
    const outcome = await startTutorStream(
      makeInput({ sessionId: 'missing-session-000' }),
      factory.deps,
    );

    expect(outcome.ok).toBe(false);
    if (!outcome.ok) {
      expect(outcome.response.success).toBe(false);
      if (!outcome.response.success) {
        expect(outcome.response.error.code).toBe('SESSION_NOT_FOUND');
      }
    }
    expect(factory.generateCalls).not.toHaveBeenCalled();
  });

  it('جلسة منتهية: فشل قبل البث', async () => {
    const sessionId = createSession();
    sessionStore.endSession(sessionId);

    const outcome = await startTutorStream(makeInput({ sessionId }));

    expect(outcome.ok).toBe(false);
    if (!outcome.ok && !outcome.response.success) {
      expect(outcome.response.error.code).toBe('SESSION_ENDED');
    }
  });

  it('اختلاف المادة: قفل المادة قبل البث', async () => {
    const sessionId = createSession('physics');

    const outcome = await startTutorStream(makeInput({ sessionId, subjectId: 'mathematics' }));

    expect(outcome.ok).toBe(false);
    if (!outcome.ok && !outcome.response.success) {
      expect(outcome.response.error.code).toBe('SUBJECT_LOCKED');
    }
  });

  it('غياب المفاتيح: NO_API_KEY قبل البث', async () => {
    const outcome = await startTutorStream(makeInput({ keys: [] }));

    expect(outcome.ok).toBe(false);
    if (!outcome.ok && !outcome.response.success) {
      expect(outcome.response.error.code).toBe('NO_API_KEY');
    }
  });
});

describe('بث ناجح', () => {
  it('يصل عدة أجزاء ثم حدث اكتمال', async () => {
    const factory = fakeClientFactory({
      chunks: [{ text: 'أهلًا' }, { text: ' بك' }, { finishReason: 'stop', usage: { outputTokens: 2 } }],
    });

    const outcome = await startTutorStream(makeInput(), factory.deps);

    expect(outcome.ok).toBe(true);
    if (!outcome.ok) {
      return;
    }
    const events = await collect(outcome.events);
    const tokens = events.filter((event) => event.type === 'token');
    expect(tokens).toHaveLength(2);
    const done = events.find((event) => event.type === 'done');
    expect(done).toBeTruthy();
    if (done?.type === 'done') {
      expect(done.usage?.outputTokens).toBe(2);
    }
  });

  it('يحافظ على النص العربي سليمًا عبر الأجزاء', async () => {
    const factory = fakeClientFactory({
      chunks: [{ text: 'المعادلات الخطية' }, { text: ' تُحل خطوة بخطوة' }],
    });

    const outcome = await startTutorStream(makeInput(), factory.deps);
    expect(outcome.ok).toBe(true);
    if (!outcome.ok) {
      return;
    }
    const events = await collect(outcome.events);
    const joined = events
      .filter((event): event is Extract<TutorStreamEvent, { type: 'token' }> => event.type === 'token')
      .map((event) => event.text)
      .join('');
    expect(joined).toBe('المعادلات الخطية تُحل خطوة بخطوة');
  });

  it('مزود بلا دعم بث: احتياط غير تدفقي بحدث واحد', async () => {
    const factory = fakeClientFactory({ noStreamSupport: true });

    const outcome = await startTutorStream(makeInput(), factory.deps);
    expect(outcome.ok).toBe(true);
    if (!outcome.ok) {
      return;
    }
    const events = await collect(outcome.events);
    const tokens = events.filter((event) => event.type === 'token');
    expect(tokens).toHaveLength(1);
    if (tokens[0]?.type === 'token') {
      expect(tokens[0].text).toBe('رد كامل احتياطي');
    }
    expect(factory.generateCalls).toHaveBeenCalledTimes(1);
  });
});

describe('أخطاء المفاتيح قبل البث', () => {
  it('مفتاح غير صالح: فشل قبل البث وتعليم المفتاح دون انتقال تلقائي', async () => {
    const outcome = await startTutorStream(
      makeInput({
        keys: [
          { id: 'k1', provider: 'mock', apiKey: 'bad-key-11111' },
          { id: 'k2', provider: 'mock', apiKey: 'other-key-222' },
        ],
      }),
      failingStreamClient({ statusCode: 401, message: 'Unauthorized' }),
    );

    expect(outcome.ok).toBe(false);
    if (!outcome.ok && !outcome.response.success) {
      expect(outcome.response.error.code).toBe('INVALID_API_KEY');
      expect(outcome.response.keyStatusUpdates).toContainEqual({ keyId: 'k1', status: 'invalid' });
      expect(outcome.response.keyStatusUpdates).not.toContainEqual(
        expect.objectContaining({ keyId: 'k2' }),
      );
    }
  });

  it('استنفاد حصة: يجرّب مفتاحًا آخر مرة واحدة وينجح', async () => {
    let callCount = 0;
    const deps: TutorServiceDeps = {
      sessionStore,
      createClient: (provider: ProviderName): ProviderClient => ({
        providerName: provider,
        generateResponse: async () => ({ text: 'غير متوقع' }),
        streamResponse: async () => {
          callCount += 1;
          const currentCall = callCount;
          async function* parts(): AsyncGenerator<ProviderStreamChunk> {
            if (currentCall === 1) {
              throw { statusCode: 429, message: 'quota exceeded' };
            }
            yield { text: 'رد المفتاح الثاني' };
          }
          return parts();
        },
      }),
    };

    const outcome = await startTutorStream(
      makeInput({
        keys: [
          { id: 'k1', provider: 'mock', apiKey: 'quota-key-111' },
          { id: 'k2', provider: 'mock', apiKey: 'quota-key-222' },
        ],
      }),
      deps,
    );

    expect(outcome.ok).toBe(true);
    if (!outcome.ok) {
      return;
    }
    const events = await collect(outcome.events);
    const done = events.find((event) => event.type === 'done');
    expect(done).toBeTruthy();
    if (done?.type === 'done') {
      expect(done.keyStatusUpdates).toContainEqual({ keyId: 'k1', status: 'exhausted' });
    }
    expect(callCount).toBe(2);
  });

  it('استنفاد كل المفاتيح: فشل موحد دون حلقة لا نهائية', async () => {
    let callCount = 0;
    const deps: TutorServiceDeps = {
      sessionStore,
      createClient: (provider: ProviderName): ProviderClient => ({
        providerName: provider,
        generateResponse: async () => ({ text: 'غير متوقع' }),
        streamResponse: async () => {
          callCount += 1;
          async function* parts(): AsyncGenerator<ProviderStreamChunk> {
            throw { statusCode: 429, message: 'quota' };
          }
          return parts();
        },
      }),
    };

    const keys: UserKeyCredential[] = Array.from({ length: 8 }, (_, index) => ({
      id: `k${index}`,
      provider: 'mock' as const,
      apiKey: `loop-key-${index}00`,
    }));

    const outcome = await startTutorStream(makeInput({ keys }), deps);

    expect(outcome.ok).toBe(false);
    if (!outcome.ok && !outcome.response.success) {
      expect(outcome.response.error.code).toBe('ALL_KEYS_EXHAUSTED');
    }
    // الحد الأعلى للمحاولات يمنع أي حلقة مفتوحة.
    expect(callCount).toBeLessThanOrEqual(5);
  });

  it('خطأ شبكة قبل البث: لا تغيير لحالة المفتاح', async () => {
    const outcome = await startTutorStream(
      makeInput(),
      failingStreamClient(new TypeError('fetch failed')),
    );

    expect(outcome.ok).toBe(false);
    if (!outcome.ok && !outcome.response.success) {
      expect(outcome.response.error.code).toBe('NETWORK_ERROR');
      expect(outcome.response.keyStatusUpdates ?? []).toEqual([]);
    }
  });

  it('إلغاء المستخدم قبل البث ليس خطأ دائمًا ولا يغيّر حالة المفتاح', async () => {
    const outcome = await startTutorStream(
      makeInput(),
      failingStreamClient(new DOMException('The operation was aborted.', 'AbortError')),
    );

    expect(outcome.ok).toBe(false);
    if (!outcome.ok && !outcome.response.success) {
      expect(outcome.response.keyStatusUpdates ?? []).toEqual([]);
    }
  });
});

describe('أخطاء أثناء البث', () => {
  it('خطأ بعد وصول بعض الأجزاء: حدث خطأ داخل البث مع الاحتفاظ بما وصل', async () => {
    const factory = fakeClientFactory({
      chunks: [{ text: 'جزء أول ' }, { text: 'جزء ثانٍ' }],
      streamError: new TypeError('connection reset'),
      streamErrorAfter: 2,
    });

    const outcome = await startTutorStream(makeInput(), factory.deps);
    expect(outcome.ok).toBe(true);
    if (!outcome.ok) {
      return;
    }
    const events = await collect(outcome.events);
    const tokens = events.filter((event) => event.type === 'token');
    expect(tokens).toHaveLength(2);
    const errorEvent = events.find((event) => event.type === 'error');
    expect(errorEvent).toBeTruthy();
    if (errorEvent?.type === 'error') {
      expect(errorEvent.code).toBe('NETWORK_ERROR');
      expect(errorEvent.retryable).toBe(true);
      // خطأ الشبكة لا يغيّر حالة المفتاح.
      expect(errorEvent.keyStatusUpdates).toEqual([]);
    }
    expect(events.find((event) => event.type === 'done')).toBeUndefined();
  });

  it('مسار الطالب لا يستخدم مفتاح البيئة حتى مع تفعيل وضع التطوير', async () => {
    vi.stubEnv('DEV_TESTING_MODE', 'true');
    vi.stubEnv('GEMINI_API_KEY', 'env-key-should-not-be-used-123');

    // المسار الكامل: بدون مفاتيح مستخدم يجب أن يعود NO_API_KEY
    // وليس مفتاح البيئة، حتى في وضع التطوير.
    const response = await processTutorRequest(makeInput({ keys: [] }));
    expect(response.success).toBe(false);
    if (!response.success) {
      expect(response.error.code).toBe('NO_API_KEY');
    }

    // مسار البث كذلك.
    const outcome = await startTutorStream(makeInput({ keys: [] }));
    expect(outcome.ok).toBe(false);
    if (!outcome.ok && !outcome.response.success) {
      expect(outcome.response.error.code).toBe('NO_API_KEY');
    }

    vi.unstubAllEnvs();
  });

  it('استنفاد حصة أثناء البث: يُعلَّم المفتاح في حدث الخطأ', async () => {
    const factory = fakeClientFactory({
      chunks: [{ text: 'بداية الرد' }],
      streamError: { statusCode: 429, message: 'quota exceeded' },
      streamErrorAfter: 1,
    });

    const outcome = await startTutorStream(makeInput(), factory.deps);
    expect(outcome.ok).toBe(true);
    if (!outcome.ok) {
      return;
    }
    const events = await collect(outcome.events);
    const errorEvent = events.find((event) => event.type === 'error');
    expect(errorEvent?.type).toBe('error');
    if (errorEvent?.type === 'error') {
      expect(errorEvent.keyStatusUpdates).toContainEqual({ keyId: 'k1', status: 'exhausted' });
    }
  });
});
