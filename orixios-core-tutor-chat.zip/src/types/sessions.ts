/**
 * أنواع المجالات: المواد والجلسات وأخطاء الجلسات.
 */

/** المعرّفات الصالحة للمواد في هذه المرحلة. */
export const SUBJECT_IDS = [
  'mathematics',
  'physics',
  'chemistry',
  'arabic',
] as const;

export type SubjectId = (typeof SUBJECT_IDS)[number];

/**
 * مادة دراسية في الكتالوج.
 * - "name": الاسم القياسي اللاتيني (يظهر في السياقات التقنية).
 * - "nameAr": اسم العرض العربي.
 * الحقول الإضافية (مثل description) توسعات اختيارية للواجهة.
 */
export interface Subject {
  id: SubjectId;
  name: string;
  nameAr: string;
  grade?: string;
  curriculum?: string;
  /** المواد غير النشطة لا تُعرض ولا تُنشأ لها جلسات. */
  isActive: boolean;
  description?: string;
}

export type SessionStatus = 'active' | 'ended';

/** جلسة تدريس واحدة، مرتبطة بمادة واحدة فقط طوال عمرها. */
export interface TutorSession {
  id: string;
  studentId: string;
  subjectId: SubjectId;
  subjectName: string;
  status: SessionStatus;
  /** تاريخ البدء بصيغة ISO. */
  startedAt: string;
  /** تاريخ الانتهاء بصيغة ISO إن وُجد. */
  endedAt?: string;
}

/** أخطاء نطاق الجلسات. */
export type SessionErrorCode =
  | 'SESSION_NOT_FOUND'
  | 'SESSION_ENDED'
  | 'SUBJECT_MISMATCH'
  | 'INVALID_SUBJECT'
  | 'SESSION_ALREADY_EXISTS';
