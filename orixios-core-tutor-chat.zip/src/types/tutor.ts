/**
 * أنواع شات المدرّس: الرسائل وأكواد الأخطاء.
 * عقد الاستجابات نفسه معرفة في "@/lib/tutor/tutor-response".
 */

export type ChatRole = 'user' | 'assistant';

export interface ChatMessage {
  role: ChatRole;
  content: string;
}

/** رسالة معروضة في واجهة الشات. */
export interface TutorMessage extends ChatMessage {
  id: string;
  /** وقت الإرسال بصيغة ISO. */
  sentAt: string;
}

/** حالة الرسالة في الواجهة: إرسال، أو بث جارٍ، أو فشل. */
export type UiMessageStatus = 'sending' | 'streaming' | 'failed';

/** رسالة واجهة الشات مع حالتها إن وجدت. */
export interface UiChatMessage extends TutorMessage {
  status?: UiMessageStatus;
}

/** أخطاء الشات القياسية التي تفهمها الواجهة. */
export type TutorErrorCode =
  | 'NO_API_KEY'
  | 'ALL_KEYS_EXHAUSTED'
  | 'INVALID_API_KEY'
  | 'SUBJECT_LOCKED'
  | 'SESSION_NOT_FOUND'
  | 'SESSION_ENDED'
  | 'INVALID_SUBJECT'
  | 'VALIDATION_ERROR'
  | 'NETWORK_ERROR'
  | 'PROVIDER_UNKNOWN'
  | 'INTERNAL_ERROR';
