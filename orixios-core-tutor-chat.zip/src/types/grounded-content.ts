/**
 * أنواع المحتوى الموثوق (Grounded Content).
 * كل شرح المدرّس يجب أن يستند حصريًا إلى هذه المصادر،
 * ولا يُدَّعى أبدًا أن المحتوى التجريبي تسجيل أو كتاب حقيقي.
 */

import type { SubjectId } from './sessions';

export type GroundedSourceType =
  | 'teacher_transcript'
  | 'whiteboard'
  | 'textbook'
  | 'ministry_exam'
  | 'mock';

export interface GroundedContent {
  id: string;
  subjectId: SubjectId;
  title: string;
  /** المحور أو الدرس الذي يغطيه المصدر. */
  topic: string;
  content: string;
  sourceType: GroundedSourceType;
  /** مرجع المصدر؛ في التطوير يكون "development-fixture". */
  sourceReference: string;
  /** المحتوى غير النشط لا يُحمَّل أبدًا. */
  isActive: boolean;
}

/** نتيجة بناء السياق الموثوق لمادة/موضوع معين. */
export interface GroundedContextResult {
  subjectId: SubjectId;
  topic?: string;
  contents: GroundedContent[];
  /** false عندما لا يوجد مصدر مناسب؛ عندها لا يُولَّد أي سياق بديل. */
  hasAvailableSource: boolean;
  context: string;
}
