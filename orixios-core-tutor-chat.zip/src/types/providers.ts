/**
 * أنواع مزودي الذكاء الاصطناعي ومفاتيح المستخدم.
 */

/**
 * المزودون المدعومون.
 * - "openrouter" و"github-models" عناصر نائبة غير مفعّلة بعد.
 * - "mock" أداة محاكاة تطويرية محلية وليس مزود ذكاء اصطناعي خارجيًا؛
 *   وجوده يسمح بتجربة الشات دون مفاتيح حقيقية، ويمكن إلغاؤه بعلامة واحدة.
 */
export const PROVIDER_NAMES = ['gemini', 'openrouter', 'github-models', 'mock'] as const;

export type ProviderName = (typeof PROVIDER_NAMES)[number];

export const API_KEY_STATUSES = ['active', 'exhausted', 'invalid'] as const;

export type ApiKeyStatus = (typeof API_KEY_STATUSES)[number];

/**
 * مفتاح API خاص بالمستخدم.
 * ملاحظة: في هذه المرحلة يُخزَّن في localStorage مؤقتًا (انظر
 * lib/ai-providers/user-keys-storage.ts). لاحقًا يُستبدل بتخزين مشفر عبر Supabase.
 */
export interface UserApiKey {
  id: string;
  provider: ProviderName;
  label: string;
  apiKey: string;
  status: ApiKeyStatus;
  isDefault: boolean;
  /** تاريخ الإنشاء بصيغة ISO. */
  createdAt: string;
}

/**
 * نسخة آمنة من المفتاح تصلح للعرض في واجهة المستخدم.
 * لا تحتوي على قيمة المفتاح الخام إطلاقًا.
 */
export interface PublicUserApiKey {
  id: string;
  provider: ProviderName;
  label: string;
  status: ApiKeyStatus;
  isDefault: boolean;
  createdAt: string;
  /** معاينة مقنّعة مثل: ••••1234 */
  keyPreview: string;
}

/** تحديث حالة مفتاح ناتج عن محاولة استدعاء فعلية (مثل استنفاد الحصة). */
export interface KeyStatusUpdate {
  keyId: string;
  status: ApiKeyStatus;
}

/**
 * بيانات اعتماد تُرسل مع طلب الشات.
 * إرسال المفتاح من العميل ضروري في مرحلة Mock فقط لأن التخزين في localStorage،
 * وسيُستبدل لاحقًا بجلب آمن من جهة الخادم عبر Supabase.
 */
export interface UserKeyCredential {
  id: string;
  provider: ProviderName;
  apiKey: string;
}
