/**
 * مؤلف المهارات: يدمج مهارات مستقلة في كتلة تعليمات واحدة.
 *
 * القواعد:
 * - ترتيب الدمج ثابت وغير عشوائي وقابل للاختبار (مصفوفة الترتيب أدناه).
 * - لا تكرار لنفس المهارة (أول ظهور يفوز)، فلا تتكرر التعليمات بلا داعٍ.
 * - المؤلف يمرر نفس السياق لكل المهارات: لا يمكنه اختيار مادة أخرى
 *   ولا تمرير سياق موثوق لمادة مختلفة.
 * - إضافة مهارة جديدة = تمريرها في المصفوفة دون تعديل بقية النظام.
 */

import { explanationSkill } from './explanation-skill';
import { groundedSourceSkill } from './grounded-source-skill';
import { sessionSubjectLockSkill } from './session-subject-lock-skill';
import type { TutorPromptContext, TutorSkill, TutorSkillName } from './types';

/** الترتيب الثابت المعتمد للمهارات الأساسية. */
export const DEFAULT_SKILL_ORDER: readonly TutorSkillName[] = [
  'session-subject-lock',
  'grounded-source',
  'explanation',
];

/** المهارات الأساسية بترتيبها الثابت. */
export function getDefaultTutorSkills(): TutorSkill[] {
  return [sessionSubjectLockSkill, groundedSourceSkill, explanationSkill];
}

/**
 * يدمج تعليمات المهارات وفق ترتيب المصفوفة الممررة.
 * عند عدم تمرير مهارات تُستخدم المهارات الأساسية الافتراضية.
 */
export function composeTutorInstructions(
  context: TutorPromptContext,
  skills: readonly TutorSkill[] = getDefaultTutorSkills(),
): string {
  const seenNames = new Set<string>();
  const blocks: string[] = [];

  for (const skill of skills) {
    if (seenNames.has(skill.name)) {
      continue; // لا تكرار لنفس المهارة
    }
    seenNames.add(skill.name);

    const instructions = skill.getInstructions(context).trim();
    if (instructions.length > 0) {
      blocks.push(instructions);
    }
  }

  return blocks.join('\n\n');
}
