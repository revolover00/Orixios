/**
 * أنواع طبقة مهارات المدرّس.
 *
 * التصميم: لا يوجد system prompt واحد ضخم؛ كل مهارة وحدة مستقلة
 * تُركَّب حسب حالة المحادثة عبر مؤلف المهارات (skill-composer).
 */

/** أسماء المهارات الأساسية المدمجة. */
export const TUTOR_SKILL_NAMES = [
  'explanation',
  'grounded-source',
  'session-subject-lock',
] as const;

/**
 * اتحاد الأسماء الأساسية، مع الجزء "(string & {})" الذي يسمح بإضافة
 * مهارات مخصصة جديدة لاحقًا دون تعديل النظام كله، مع بقاء الإكمال
 * التلقائي للأسماء الأساسية.
 */
export type TutorSkillName = (typeof TUTOR_SKILL_NAMES)[number] | (string & {});

/** سياق بناء التعليمات: كل ما تحتاجه المهارات، ولا شيء خارجه. */
export interface TutorPromptContext {
  subjectId: string;
  subjectName: string;
  currentTopic?: string;
  /** نص السياق الموثوق الجاهز (فارغ عندما لا يتوفر مصدر). */
  groundedContext: string;
  hasAvailableSource: boolean;
  sessionId: string;
}

/** مهارة مدرّس مستقلة قابلة للتركيب. */
export interface TutorSkill {
  name: TutorSkillName;
  getInstructions(context: TutorPromptContext): string;
}
