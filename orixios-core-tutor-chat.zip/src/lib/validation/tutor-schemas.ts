/**
 * مخططات Zod للتحقق من صحة المدخلات.
 */

import { z } from 'zod';
import { PROVIDERS } from '@/lib/ai-providers/provider-config';
import { PROVIDER_NAMES } from '@/types/providers';
import { SUBJECT_IDS } from '@/types/sessions';

/**
 * رسالة واحدة من العميل.
 * - الأدوار المسموحة: user وassistant فقط؛ أي دور آخر
 *   (مثل system أو tool أو developer) يُرفض فورًا.
 * - معرّف الرسالة اختياري ويُهمل خادميًا (لا يُوثق به).
 */
export const chatMessageSchema = z.object({
  id: z.string().max(128).optional(),
  role: z.enum(['user', 'assistant'], {
    error: 'نوع الرسالة يجب أن يكون user أو assistant فقط',
  }),
  content: z
    .string()
    .trim()
    .min(1, 'محتوى الرسالة مطلوب')
    .max(6000, 'الرسالة طويلة جدًا'),
});

export const userKeyCredentialSchema = z.object({
  id: z.string().min(1).max(128),
  provider: z.enum(PROVIDER_NAMES),
  apiKey: z
    .string()
    .min(8, 'قيمة المفتاح قصيرة جدًا')
    .max(512, 'قيمة المفتاح طويلة جدًا'),
});

/** مخطط جسم الطلب POST /api/tutor */
export const tutorChatRequestSchema = z.object({
  sessionId: z
    .string()
    .trim()
    .min(8, 'معرّف الجلسة مطلوب (8 محارف على الأقل)')
    .max(128),
  subjectId: z.enum(SUBJECT_IDS, {
    error: 'المادة غير صالحة',
  }),
  messages: z
    .array(chatMessageSchema)
    .min(1, 'يجب إرسال رسالة واحدة على الأقل')
    .max(100, 'عدد الرسائل في الطلب الواحد كبير جدًا'),
  currentTopic: z.string().trim().min(1).max(200).optional(),
  keys: z.array(userKeyCredentialSchema).max(20).default([]),
  /** اختياري: "true" يرجع استجابة بث (SSE)، وغیابه يحافظ على السلوك العادي. */
  stream: z.boolean().optional(),
});

export type TutorChatRequestInput = z.infer<typeof tutorChatRequestSchema>;

/** مخطط نموذج إضافة مفتاح في صفحة الإعدادات (تحقق في العميل). */
export const addApiKeySchema = z.object({
  provider: z.enum(PROVIDER_NAMES, { error: 'اختر مزودًا من القائمة المسموحة' }),
  label: z
    .string()
    .trim()
    .min(1, 'التسمية مطلوبة ولا يمكن أن تكون مسافات فقط')
    .max(60, 'التسمية طويلة جدًا'),
  apiKey: z
    .string()
    .trim()
    .min(8, 'قيمة المفتاح قصيرة جدًا أو فارغة (8 محارف على الأقل)')
    .max(512, 'قيمة المفتاح طويلة جدًا'),
});

export type AddApiKeyInput = z.infer<typeof addApiKeySchema>;

/**
 * مخطط نموذج إضافة مفتاح في صفحة الإعدادات، مع منع حفظ مفتاح لمزود
 * غير مفعّل (العناصر النائبة مثل OpenRouter وGitHub Models).
 */
export const apiKeyFormSchema = addApiKeySchema.superRefine((value, ctx) => {
  const definition = PROVIDERS[value.provider];
  if (!definition || definition.enabled !== true || definition.isPlaceholder) {
    ctx.addIssue({
      code: 'custom',
      path: ['provider'],
      message: 'هذا المزود غير متاح للحفظ في هذه المرحلة.',
    });
  }
});

export type ApiKeyFormInput = z.infer<typeof apiKeyFormSchema>;

/** مخطط اختيار مفتاح موجود (تحقق من وجود معرّف صالح). */
export const selectKeySchema = z.object({
  keyId: z.string().trim().min(1, 'معرّف المفتاح مطلوب').max(128),
});

export type SelectKeyInput = z.infer<typeof selectKeySchema>;

/** مخطط اختيار مزود. */
export const providerNameSchema = z.enum(PROVIDER_NAMES, {
  error: 'اسم المزود غير صالح',
});

export const selectProviderSchema = z.object({
  provider: providerNameSchema,
});

export type SelectProviderInput = z.infer<typeof selectProviderSchema>;

/** تلخيص رسائل أخطاء Zod في نص قصير قابل للعرض. */
export function summarizeZodIssues(error: z.ZodError): string {
  return error.issues
    .slice(0, 3)
    .map((issue) => {
      const path = issue.path.join('.') || 'الطلب';
      return `${path}: ${issue.message}`;
    })
    .join('؛ ');
}
