/**
 * مخططات Zod لنطاق الجلسات والمواد.
 * ترفض: القيم الفارغة، المسافات فقط، والقيم غير المعروفة.
 */

import { z } from 'zod';
import { SUBJECT_IDS } from '@/types/sessions';

function trimIfString(value: unknown): unknown {
  return typeof value === 'string' ? value.trim() : value;
}

/** معرّف الطالب: غير فارغ وبعد قص المسافات. */
export const studentIdSchema = z
  .string()
  .trim()
  .min(1, 'معرّف الطالب مطلوب ولا يمكن أن يكون مسافات فقط')
  .max(128, 'معرّف الطالب طويل جدًا');

/** معرّف المادة: مقصوص المسافات ومن القائمة المعروفة فقط. */
export const subjectIdSchema = z.preprocess(
  trimIfString,
  z.enum(SUBJECT_IDS, { error: 'المادة غير معروفة' }),
);

/** معرّف الجلسة. */
export const sessionIdSchema = z
  .string()
  .trim()
  .min(8, 'معرّف الجلسة مطلوب (8 محارف على الأقل)')
  .max(128, 'معرّف الجلسة طويل جدًا');

/**
 * التحقق من معرّف المادة القادم من مقطع الرابط /session/[subjectId].
 * مقاطع الروابط لا تحتوي مسافات زائدة أصلًا، لكن نطبّق نفس الصرامة.
 */
export const urlSubjectIdSchema = z.preprocess(
  trimIfString,
  z.enum(SUBJECT_IDS, { error: 'المادة في الرابط غير صالحة' }),
);

/** جسم إنشاء جلسة. */
export const createSessionSchema = z.object({
  studentId: studentIdSchema,
  subjectId: subjectIdSchema,
});

export type CreateSessionSchemaInput = z.infer<typeof createSessionSchema>;

/** قراءة معرّف جلسة من طلب. */
export const readSessionSchema = z.object({
  sessionId: sessionIdSchema,
});

export type ReadSessionSchemaInput = z.infer<typeof readSessionSchema>;
